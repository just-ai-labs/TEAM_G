import faiss
import numpy as np

def create_index(dim):
    """Create a FAISS index for vector search."""
    index = faiss.IndexFlatL2(dim)
    return index

def add_vectors(index, vectors):
    """Add vectors to the FAISS index."""
    index.add(np.array(vectors).astype(np.float32))

def search_index(index, query_vector, k=5):
    """Search the FAISS index with a query vector."""
    D, I = index.search(np.array([query_vector]).astype(np.float32), k)
    return I  # Returns the indices of the nearest neighbors
