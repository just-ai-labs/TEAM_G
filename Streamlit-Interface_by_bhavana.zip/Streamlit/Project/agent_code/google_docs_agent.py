from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents.readonly']

def authenticate_google_docs():
    """Authenticate and return the Google Docs API client."""
    creds = None
    if creds and creds.valid:
        return build('docs', 'v1', credentials=creds)

    flow = InstalledAppFlow.from_client_secrets_file(
        'credentials/credentials.json', SCOPES)
    creds = flow.run_local_server(port=0)
    return build('docs', 'v1', credentials=creds)

def get_document(doc_id):
    """Fetch a Google Doc by its document ID."""
    service = authenticate_google_docs()
    document = service.documents().get(documentId=doc_id).execute()
    return document
