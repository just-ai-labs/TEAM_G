import os
import json

def load_token(file_path):
    """Load a token from a JSON file."""
    with open(file_path, 'r') as file:
        return json.load(file)

def save_token(token, file_path):
    """Save a token to a JSON file."""
    with open(file_path, 'w') as file:
        json.dump(token, file)
