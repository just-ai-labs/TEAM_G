from github import Github

def authenticate_github(token):
    """Authenticate and return the GitHub API client."""
    g = Github(token)
    return g

def create_issue(repo_name, title, body, token):
    """Create an issue on GitHub."""
    g = authenticate_github(token)
    repo = g.get_repo(repo_name)
    issue = repo.create_issue(title=title, body=body)
    return issue
