
# Instead of SimpleChain
from langchain.chains import LLMChain

from langchain.prompts import PromptTemplate

def langchain_agent(input_text):
    """Simple LangChain agent to process input and return output."""
    prompt_template = PromptTemplate(input_variables=["text"], template="Process the following: {text}")
    chain = LLMChain(prompt_template)
    return chain.run(input_text)
