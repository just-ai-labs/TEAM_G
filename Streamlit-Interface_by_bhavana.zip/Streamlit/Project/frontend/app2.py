import requests 
import json

# GitHub token and repository URL setup
GITHUB_TOKEN = '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'  # Replace with your GitHub token
GITHUB_API_URL = 'https://api.github.com'

def process_command(command):
    if command == "create repository":
        create_repository()
    elif command == "create task":
        create_task()
    elif command == "update task":
        update_task()
    elif command == "assign task":
        assign_task()
    elif command == "create pull request":
        create_pull_request()
    elif command == "repository status":
        repository_status()
    elif command == "check commits":
        check_commits()
    elif command == "view all tasks":
        view_all_tasks()
    elif command == "add label to issue":
        add_label_to_issue()
    elif command == "view pull requests":
        view_pull_requests()
    elif command == "exit":
        print("Bot is shutting down.")
        exit()
    else:
        print("Invalid command.")

# 1. **Create Repository**
def create_repository():
    repo_name = input("Enter repository name: ")
    repo_description = input("Enter repository description: ")
    
    url = f"{GITHUB_API_URL}/user/repos"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "name": repo_name,
        "description": repo_description
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        print(f"Repository '{repo_name}' has been created successfully.")
    else:
        print(f"Error creating repository: {response.json()}")

# 2. **Create Task (Issue)**
def create_task():
    repo_name = input("Enter repository name: ")
    task_title = input("Enter the task title: ")
    task_description = input("Enter the task description: ")
    assignee = input("Enter the assignee username: ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}/issues"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "title": task_title,
        "body": task_description,
        "assignees": [assignee]
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        print(f"Task '{task_title}' has been created and assigned to {assignee}.")
    else:
        print(f"Error creating task: {response.json()}")

# 3. **Update Task (Issue)**
def update_task():
    repo_name = input("Enter repository name: ")
    issue_number = int(input("Enter issue number: "))
    new_title = input("Enter new task title: ")
    new_description = input("Enter new task description: ")

    url = f"{GITHUB_API_URL}/repos/{repo_name}/issues/{issue_number}"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "title": new_title,
        "body": new_description
    }
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code == 200:
        print(f"Issue #{issue_number} has been updated to '{new_title}'.")
    else:
        print(f"Error updating task: {response.json()}")

# 4. **Assign Task**
def assign_task():
    repo_name = input("Enter repository name: ")
    issue_number = int(input("Enter issue number: "))
    assignee = input("Enter username to assign: ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}/issues/{issue_number}"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "assignees": [assignee]
    }
    
    response = requests.patch(url, json=data, headers=headers)
    
    if response.status_code == 200:
        print(f"Issue #{issue_number} has been assigned to {assignee}.")
    else:
        print(f"Error assigning task: {response.json()}")

# 5. **Create Pull Request**
def create_pull_request():
    repo_name = input("Enter repository name: ")
    source_branch = input("Enter source branch name: ")
    target_branch = input("Enter target branch name: ")
    pr_title = input("Enter pull request title: ")
    pr_description = input("Enter pull request description: ")

    url = f"{GITHUB_API_URL}/repos/{repo_name}/pulls"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "title": pr_title,
        "head": source_branch,
        "base": target_branch,
        "body": pr_description
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 201:
        print(f"Pull request has been created successfully from '{source_branch}' to '{target_branch}'.")
    else:
        print(f"Error creating pull request: {response.json()}")

# 6. **Repository Status**
def repository_status():
    repo_name = input("Enter repository name: ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        repo_data = response.json()
        print(f"Repository '{repo_name}' status:")
        print(f"Description: {repo_data['description']}")
        print(f"Open issues: {repo_data['open_issues_count']}")
        print(f"Forks: {repo_data['forks_count']}")
        print(f"Stars: {repo_data['stargazers_count']}")
    else:
        print(f"Error fetching repository status: {response.json()}")

# 7. **Check Commits**
def check_commits():
    repo_name = input("Enter repository name: ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}/commits"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        commits = response.json()
        print(f"Commits in '{repo_name}':")
        for commit in commits[:5]:  # Show the last 5 commits
            print(f"Commit by {commit['commit']['author']['name']}: {commit['commit']['message']}")
    else:
        print(f"Error fetching commits: {response.json()}")

# 8. **View All Tasks**
def view_all_tasks():
    repo_name = input("Enter repository name: ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}/issues"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        tasks = response.json()
        print(f"Tasks in '{repo_name}':")
        for task in tasks:
            print(f"#{task['number']} - {task['title']} (Assigned to {task['assignee'] if task['assignee'] else 'None'})")
    else:
        print(f"Error fetching tasks: {response.json()}")

# 9. **Add Label to Issue**
def add_label_to_issue():
    repo_name = input("Enter repository name: ")
    issue_number = int(input("Enter issue number: "))
    label = input("Enter label to add (e.g., bug, enhancement): ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}/issues/{issue_number}/labels"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    data = {
        "labels": [label]
    }
    
    response = requests.post(url, json=data, headers=headers)
    
    if response.status_code == 200:
        print(f"Label '{label}' has been added to issue #{issue_number}.")
    else:
        print(f"Error adding label: {response.json()}")

# 10. **View Pull Requests**
def view_pull_requests():
    repo_name = input("Enter repository name: ")
    
    url = f"{GITHUB_API_URL}/repos/{repo_name}/pulls"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        pull_requests = response.json()
        print(f"Pull Requests in '{repo_name}':")
        for pr in pull_requests:
            print(f"#{pr['number']} - {pr['title']} (by {pr['user']['login']})")
    else:
        print(f"Error fetching pull requests: {response.json()}")

# 11. **Exit**
def exit_bot():
    print("Bot is shutting down.")
    exit()

# Main function to run the chat interface
if __name__ == "__main__":
    while True:
        command = input("Enter command: ")
        process_command(command)  



import streamlit as st
from backend import process_command

# Streamlit chat interface setup
st.set_page_config(layout="wide")
st.title("GitHub Task Manager Chat Interface")
st.markdown("Interact with GitHub tasks using commands below.")



# Add custom CSS for styling
st.markdown(
    """
    <style>
    .chat-input-container {
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: white;
        padding: 10px;
        box-shadow: 0px -2px 5px rgba(0,0,0,0.1);
        z-index: 100;
    }

    .chat-input-container input {
        width: 100%;
        max-width: 800px;
        height: 40px;
        padding: 10px;
        font-size: 16px;
    }

    .chat-history {
        height: 70vh;
        overflow-y: auto;
        padding-bottom: 20px;
    }

    .chat-history div {
        word-wrap: break-word;
    }

    .main {
        margin-bottom: 80px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state['messages'] = []
if 'user_input' not in st.session_state:
    st.session_state['user_input'] = ""

# Callback function to process input
def handle_input():
    user_input = st.session_state['user_input'].strip()  # Strip extra spaces
    if not user_input:
        st.warning("Please enter a valid command.")
        return

    # Add user's input to chat history
    st.session_state['messages'].append({"role": "user", "content": user_input})

    # Process the command and add the response
    try:
        with st.spinner("Processing..."):
            response = process_command(user_input)
    except Exception as e:
        response = f"An error occurred: {str(e)}"

    st.session_state['messages'].append({"role": "assistant", "content": response})

    # Clear the input field
    st.session_state['user_input'] = ""

# Display chat history
st.markdown('<div class="chat-history">', unsafe_allow_html=True)
for message in st.session_state['messages']:
    if message["role"] == "user":
        st.markdown(
            f'<div style="background-color:#f0f0f0; padding:10px; margin-bottom:5px;"><strong>You</strong>: {message["content"]}</div>',
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            f'<div style="background-color:#e0f7fa; padding:10px; margin-bottom:5px;"><strong>Assistant</strong>: {message["content"]}</div>',
            unsafe_allow_html=True
        )
st.markdown('</div>', unsafe_allow_html=True)

# Add a button to clear chat history
if st.button("Clear Chat"):
    st.session_state['messages'] = []

# Fixed chat input at the bottom
st.markdown('<div class="chat-input-container">', unsafe_allow_html=True)
st.text_input(
    "You:",
    value="",
    placeholder="Enter your command...",
    key="user_input",
    on_change=handle_input,  # Use callback to handle input
)
st.markdown('</div>', unsafe_allow_html=True)
 