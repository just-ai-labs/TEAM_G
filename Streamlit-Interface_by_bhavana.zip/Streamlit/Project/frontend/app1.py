import streamlit as st
from backend import process_command  # Ensure this is imported correctly

# Streamlit chat interface setup
st.set_page_config(layout="wide")
st.title("GitHub Task Manager Chat Interface")
st.markdown("Interact with GitHub tasks using commands below.")

# Add custom CSS for styling
st.markdown(
    """
    <style>
    .chat-input-container {
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: white;
        padding: 10px;
        box-shadow: 0px -2px 5px rgba(0,0,0,0.1);
        z-index: 100;
    }

    .chat-input-container input {
        width: 100%;
        max-width: 800px;
        height: 40px;
        padding: 10px;
        font-size: 16px;
    }

    .chat-history {
        height: 70vh;
        overflow-y: auto;
        padding-bottom: 20px;
    }

    .chat-history div {
        word-wrap: break-word;
    }

    .main {
        margin-bottom: 80px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state['messages'] = []
    print("Initializing messages")  # Debugging line
if 'user_input' not in st.session_state:
    st.session_state['user_input'] = ""

# Callback function to process input
def handle_input():
    user_input = st.session_state['user_input'].strip()  # Strip extra spaces
    print(f"User Input: {user_input}")  # Debugging line
    if not user_input:
        st.warning("Please enter a valid command.")
        return

    # Add user's input to chat history
    st.session_state['messages'].append({"role": "user", "content": user_input})

    # Process the command and add the response
    try:
        with st.spinner("Processing..."):
            response = process_command(user_input)
            print(f"Response from backend: {response}")  # Debugging line
    except Exception as e:
        response = f"An error occurred: {str(e)}"

    st.session_state['messages'].append({"role": "assistant", "content": response})

    # Clear the input field
    st.session_state['user_input'] = ""

# Display chat history
st.markdown('<div class="chat-history">', unsafe_allow_html=True)
for message in st.session_state['messages']:
    if message["role"] == "user":
        st.markdown(
            f'<div style="background-color:#f0f0f0; padding:10px; margin:5px;">User: {message["content"]}</div>',
            unsafe_allow_html=True
        )
    else:
        st.markdown(
            f'<div style="background-color:#d0f0c0; padding:10px; margin:5px;">Assistant: {message["content"]}</div>',
            unsafe_allow_html=True
        )
st.markdown('</div>', unsafe_allow_html=True)

# Input field to send commands
with st.container():
    user_input = st.text_input("Enter your command:", key="user_input")
    submit_button = st.button("Send", on_click=handle_input)
