from github import Github
import re

# GitHub Authentication
GITHUB_TOKEN = "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"  # Replace with your GitHub token
GITHUB_API_URL = 'https://api.github.com'

# Initialize GitHub API client
g = Github(GITHUB_TOKEN)

# Global variables to store intermediate responses
pending_data = {}

def create_repository(name: str, description: str = "", private: bool = False):
    """Creates a new repository in GitHub."""
    try:
        repo = g.get_user().create_repo(name, description=description, private=private)
        return f"Repository '{repo.name}' created successfully! Description: '{description}', Private: {private}"
    except Exception as e:
        return f"Error creating repository: {str(e)}"

def create_issue(repo, title: str, description: str):
    """Creates a new issue in the repository."""
    try:
        issue = repo.create_issue(title=title, body=description)
        return f"Issue created successfully! Issue #{issue.number} - {issue.title}. Would you like to do anything else?"
    except Exception as e:
        return f"Error creating issue: {str(e)}"

def update_issue(repo, issue_number: int, new_title: str, new_description: str):
    """Updates an existing issue with a new title and description."""
    try:
        issue = repo.get_issue(number=issue_number)
        issue.edit(title=new_title, body=new_description)
        return f"Issue #{issue_number} has been updated with the new title and description. Would you like to do anything else?"
    except Exception as e:
        return f"Error updating issue: {str(e)}"

def assign_issue(repo, issue_number: int, assignee: str):
    """Assigns an issue to a user."""
    try:
        issue = repo.get_issue(number=issue_number)
        issue.add_to_assignees(assignee)
        return f"Issue #{issue_number} has been assigned to {assignee}. Would you like to do anything else?"
    except Exception as e:
        return f"Error assigning issue: {str(e)}"

def cancel_process():
    """Cancels the current operation and resets the state."""
    global pending_data
    pending_data.clear()
    return "The current process has been canceled. You can now start a new operation."

def process_command(command: str):
    global pending_data

    # Cancel any ongoing process
    if command.lower() == "cancel":
        return cancel_process()

    # Command parsing: Creating repository
    if re.search(r"create\s*repository", command, re.IGNORECASE):
        if 'creating_repository' not in pending_data:
            pending_data['creating_repository'] = True
            return "Please provide the name for the repository."

        else:
            return "You are already in the process of creating a repository. Please provide the description next."

    # If name is provided, move to description
    if 'creating_repository' in pending_data and 'repo_name' not in pending_data:
        pending_data['repo_name'] = command
        pending_data['creating_repository'] = False
        return "Please provide a description for the repository (optional)."

    # If description is provided after repository name
    if 'repo_name' in pending_data and 'description' not in pending_data:
        pending_data['description'] = command
        return "Should the repository be private? (yes/no)"

    # If private/public option is provided
    if 'description' in pending_data:
        description = pending_data['description']
        name = pending_data['repo_name']
        private = True if command.strip().lower() == "yes" else False
        pending_data.clear()  # Clear the pending data once the repository is created
        # Create the repository and set it for future operations
        repo = g.get_user().create_repo(name, description=description, private=private)
        pending_data['repo'] = repo
        return f"Repository '{repo.name}' created successfully! You can now create issues or perform other operations."

    # Command parsing: Creating issue (after repository creation)
    if 'repo' in pending_data and re.search(r"create\s*issue", command, re.IGNORECASE):
        if 'creating_issue' not in pending_data:
            pending_data['creating_issue'] = True
            return "Please provide the title for the issue."
        else:
            return "You are already in the process of creating an issue. Please provide the description next."

    # If title is provided, move to description
    if 'creating_issue' in pending_data and 'title' not in pending_data:
        pending_data['title'] = command
        pending_data['creating_issue'] = False
        return "Please provide a description for the issue."

    # If description is provided after issue creation
    if 'title' in pending_data:
        description = command
        title = pending_data.get("title")
        repo = pending_data['repo']
        pending_data.clear()  # Clear the pending data once the issue is created
        return create_issue(repo, title, description)

    # Command parsing: Updating issue
    elif "update issue" in command.lower():
        match = re.search(r"update issue #(\d+)", command, re.IGNORECASE)
        if match:
            issue_number = int(match.group(1))
            pending_data['updating_issue'] = True
            pending_data['issue_number'] = issue_number
            return "Please provide the new title for the issue."

    # If title is provided for update
    if 'updating_issue' in pending_data and 'new_title' not in pending_data:
        pending_data['new_title'] = command
        return "Please provide the new description for the issue."

    # If description is provided for update
    if 'new_title' in pending_data and 'new_description' not in pending_data:
        new_description = command
        new_title = pending_data.get('new_title')
        issue_number = pending_data.get('issue_number')
        repo = pending_data['repo']
        pending_data.clear()  # Clear the pending data once the issue is updated
        return update_issue(repo, issue_number, new_title, new_description)

    # Command parsing: Assigning issue
    elif "assign issue" in command.lower():
        match = re.search(r"assign issue #(\d+)", command, re.IGNORECASE)
        if match:
            issue_number = int(match.group(1))
            pending_data['assigning_issue'] = True
            pending_data['issue_number'] = issue_number
            return "Please provide the username of the assignee."

    # If assignee username is provided for assigning
    if 'assigning_issue' in pending_data and 'assignee' not in pending_data:
        pending_data['assignee'] = command
        issue_number = pending_data.get('issue_number')
        assignee = pending_data.get('assignee')
        repo = pending_data['repo']
        pending_data.clear()  # Clear the pending data once the issue is assigned
        return assign_issue(repo, issue_number, assignee)

    # Unrecognized command response
    else:
        return f"Command not recognized. Please provide a valid command."

# Sample usage
command = "create repository"
response = process_command(command)
print(response)  # Prompts for repo name

# After providing name
command = "Test Repo"
response = process_command(command)
print(response)  # Prompts for description

# After providing description
command = "This is a test repository."
response = process_command(command)
print(response)  # Prompts for privacy setting

# After providing privacy
command = "yes"
response = process_command(command)
print(response)  # Repository created, prompts for next operations
