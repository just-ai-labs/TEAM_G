# Project Name: Agent Interface

## Overview

This project integrates multiple agents including Google Docs, GitHub, vector databases, and LangChain. It provides a frontend interface using Streamlit to interact with these agents.

## Setup

1. Clone this repository.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
