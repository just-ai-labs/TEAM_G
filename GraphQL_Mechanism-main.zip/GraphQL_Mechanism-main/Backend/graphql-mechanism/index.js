// Import required modules
const { ApolloServer, gql } = require("apollo-server");
const mongoose = require("mongoose");
require("dotenv").config(); // For environment variables
const axios = require("axios");

// ---------------------
// Database Configuration
// ---------------------
mongoose
  .connect("mongodb://localhost:27017/project_db", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB connected successfully"))
  .catch((err) => console.error("MongoDB connection error:", err));

// ---------------------
// Define MongoDB Schemas and Models
// ---------------------
const TeamMemberSchema = new mongoose.Schema({
  name: String,
  role: String,
});

const ProjectSchema = new mongoose.Schema({
  projectId: String,
  name: String,
  teamMembers: [TeamMemberSchema],
});

const Project = mongoose.model("Project", ProjectSchema);

// ---------------------
// Apollo GraphQL Type Definitions
// ---------------------
const typeDefs = gql`
  type TeamMember {
    name: String
    role: String
  }

  input TeamMemberInput {
    name: String!
    role: String!
  }

  type Project {
    projectId: ID!
    name: String
    teamMembers: [TeamMember]
  }

  type Query {
    getTeamMembers(projectId: ID!): [TeamMember]
    getProject(projectId: ID!): Project
    getAllProjects: [Project]
  }

  type Mutation {
    addTeamMember(projectId: String!, name: String!, role: String!): Project
    updateTeamMemberRole(projectId: ID!, memberName: String!, role: String!): Project
    deleteTeamMember(projectId: ID!, memberName: String!): Project
    createProject(name: String!, teamMembers: [TeamMemberInput!]!): Project
    updateProject(projectId: ID!, name: String, teamMembers: [TeamMemberInput!]): Project
    deleteProject(projectId: ID!): String
    createGitHubIssue(repo: String!, title: String!, body: String!, assignee: String): String
  }
`;

// ---------------------
// Apollo GraphQL Resolvers
// ---------------------
const resolvers = {
  Query: {
    getTeamMembers: async (_, { projectId }) => {
      const project = await Project.findOne({ projectId });
      return project ? project.teamMembers : [];
    },
    getProject: async (_, { projectId }) => {
      const project = await Project.findOne({ projectId });
      if (!project) throw new Error("Project not found");
      return project;
    },
    getAllProjects: async () => {
      return await Project.find({});
    },
  },
  Mutation: {
    addTeamMember: async (_, { projectId, name, role }) => {
      const project = await Project.findOne({ projectId });
      if (project) {
        project.teamMembers.push({ name, role });
        await project.save();
        return project;
      }
      throw new Error("Project not found");
    },
    updateTeamMemberRole: async (_, { projectId, memberName, role }) => {
      const project = await Project.findOne({ projectId });
      if (project) {
        const member = project.teamMembers.find((m) => m.name === memberName);
        if (member) {
          member.role = role;
          await project.save();
          return project;
        }
        throw new Error("Team member not found");
      }
      throw new Error("Project not found");
    },
    deleteTeamMember: async (_, { projectId, memberName }) => {
      const project = await Project.findOne({ projectId });
      if (project) {
        project.teamMembers = project.teamMembers.filter((m) => m.name !== memberName);
        await project.save();
        return project;
      }
      throw new Error("Project not found");
    },
    createProject: async (_, { name, teamMembers }) => {
      const projects = await Project.find({});
      const newProjectId =
        projects.length > 0 ? Math.max(...projects.map((p) => parseInt(p.projectId))) + 1 : 1;
      const newProject = new Project({ projectId: newProjectId.toString(), name, teamMembers });
      await newProject.save();
      return newProject;
    },
    updateProject: async (_, { projectId, name, teamMembers }) => {
      const project = await Project.findOne({ projectId });
      if (!project) throw new Error("Project not found");
      if (name) project.name = name;
      if (teamMembers) project.teamMembers = teamMembers;
      await project.save();
      return project;
    },
    deleteProject: async (_, { projectId }) => {
      const project = await Project.findOneAndDelete({ projectId });
      if (!project) throw new Error("Project not found");
      return "Project deleted successfully";
    },
    createGitHubIssue: async (_, { repo, title, body, assignee }) => {
      try {
        const response = await axios.post(
          `https://api.github.com/repos/${repo}/issues`,
          { title, body, assignee },
          {
            headers: {
              Authorization: `token ${process.env.GITHUB_TOKEN}`,
            },
          }
        );
        return `Issue created: ${response.data.html_url}`;
      } catch (error) {
        throw new Error(
          error.response?.data?.message || "Failed to create issue"
        );
      }
    },
  },
};

// ---------------------
// Initialize Apollo Server
// ---------------------
const server = new ApolloServer({ typeDefs, resolvers });

server
  .listen({ port: 5000 })
  .then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
  })
  .catch((err) => console.error("Error starting server:", err));
