import streamlit as st
import requests

GRAPHQL_URL = "http://localhost:5000/graphql"  
GITHUB_API_URL = "http://localhost:5000/github/issue"  

# Function to create a new project    
def create_project(name, team_members): 
    query = """
    mutation CreateProject($name: String!, $teamMembers: [TeamMemberInput!]!) {
        createProject(name: $name, teamMembers: $teamMembers) {
            projectId
            name
            teamMembers {
                name
                role
            }
        }
    }
    """
    variables = {
        "name": name,
        "teamMembers": team_members
    }
    response = requests.post(GRAPHQL_URL, json={'query': query, 'variables': variables})
    return response.json()

# Function to get a single project
def get_project(project_id):
    query = """
    query GetProject($projectId: ID!) {
        getProject(projectId: $projectId) {
            projectId
            name
            teamMembers {
                name
                role
            }
        }
    }
    """
    variables = {
        "projectId": project_id
    }
    response = requests.post(GRAPHQL_URL, json={'query': query, 'variables': variables})
    return response.json()

# Function to get all projects
def get_all_projects():
    query = """
    query {
        getAllProjects {
            projectId
            name
            teamMembers {
                name
                role
            }
        }
    }
    """
    response = requests.post(GRAPHQL_URL, json={'query': query})
    return response.json()

# Function to update a project
def update_project(project_id, name=None, team_members=None):
    query = """
    mutation UpdateProject($projectId: ID!, $name: String, $teamMembers: [TeamMemberInput!]) {
        updateProject(projectId: $projectId, name: $name, teamMembers: $teamMembers) {
            projectId
            name
            teamMembers {
                name
                role
            }
        }
    }
    """
    variables = {
        "projectId": project_id,
        "name": name,
        "teamMembers": team_members
    }
    response = requests.post(GRAPHQL_URL, json={'query': query, 'variables': variables})
    return response.json()

# Function to delete a project
def delete_project(project_id):
    query = """
    mutation DeleteProject($projectId: ID!) {
        deleteProject(projectId: $projectId)
    }
    """
    variables = {
        "projectId": project_id
    }
    response = requests.post(GRAPHQL_URL, json={'query': query, 'variables': variables})
    return response.json()

# Streamlit UI
# st.title("Testing Interface for Team E - GraphQL Mechanism.")
st.title("GraphQL Mechanism.")
st.subheader("Project Management Dashboard")

# Dashboard navigation
option = st.sidebar.selectbox("Choose a function", ["Create Project", "View All Projects", "View Project Details", "Update Project", "Delete Project", "Create GitHub Issue"])

if option == "Create Project":
    st.header("Create Project")
    name = st.text_input("Project Name")
    team_members = st.text_area("Team Members (JSON format)")

    if st.button("Create Project"):
        try:
            team_members_data = eval(team_members)
            result = create_project(name, team_members_data)
            if 'errors' in result:
                st.error(result['errors'][0]['message'])
            else:
                st.success(f"Project '{result['data']['createProject']['name']}' created successfully!")
        except Exception as e:
            st.error(f"Error: {str(e)}")

elif option == "View All Projects":
    st.header("All Projects")
    if st.button("Fetch Projects"):
        projects = get_all_projects()
        if 'errors' in projects:
            st.error(projects['errors'][0]['message'])
        else:
            project_data = projects['data']['getAllProjects']
            if project_data:
                for project in project_data:
                    st.subheader(f"Project ID: {project['projectId']}")
                    st.write(f"Project Name: {project['name']}")
                    st.write("Team Members:")
                    for member in project['teamMembers']:
                        st.write(f"- {member['name']} ({member['role']})")
            else:
                st.info("No projects found.")

elif option == "View Project Details":
    st.header("Get Project Details")
    project_id = st.text_input("Project ID")

    if st.button("Fetch Project"):
        project = get_project(project_id)
        if 'errors' in project:
            st.error(project['errors'][0]['message'])
        else:
            project_data = project['data']['getProject']
            if project_data:
                st.write(f"Project ID: {project_data['projectId']}")
                st.write(f"Project Name: {project_data['name']}")
                st.write("Team Members:")
                for member in project_data['teamMembers']:
                    st.write(f"- {member['name']} ({member['role']})")
            else:
                st.info("Project not found.")

elif option == "Update Project":
    st.header("Update Project")
    project_id = st.text_input("Project ID to Update")
    name = st.text_input("New Project Name (leave blank to skip)")
    team_members = st.text_area("New Team Members (JSON format, leave blank to skip)")

    if st.button("Update Project"):
        try:
            team_members_data = eval(team_members) if team_members else None
            result = update_project(project_id, name if name else None, team_members_data)
            if 'errors' in result:
                st.error(result['errors'][0]['message'])
            else:
                st.success(f"Project '{result['data']['updateProject']['name']}' updated successfully!")
        except Exception as e:
            st.error(f"Error: {str(e)}")

elif option == "Delete Project":
    st.header("Delete Project")
    project_id = st.text_input("Project ID to Delete")

    if st.button("Delete Project"):
        result = delete_project(project_id)
        if 'errors' in result:
            st.error(result['errors'][0]['message'])
        else:
            message = result['data']['deleteProject']
            st.success(message)

elif option == "Create GitHub Issue":
   st.header("GitHub Issue Management")
   
   # Input Fields
   repo = st.text_input("Repository (e.g., username/repo)")
   issue_title = st.text_input("Issue Title")
   issue_body = st.text_area("Issue Description")
   issue_assignee = st.text_input("Assignee (GitHub Username)")

   # Button to create the issue
   if st.button("Create GitHub Issue"):
        # Preparing payload
        payload = {
            "repo": repo,
            "title": issue_title,
            "body": issue_body,
            "assignee": issue_assignee,
        }
        try:
            # Sending request to the backend API
            response = requests.post(GITHUB_API_URL, json=payload)
            if response.status_code == 200:
                issue_url = response.json().get("html_url")
                st.success(f"Issue created successfully: [View Issue]({issue_url})")
            else:
                st.error(f"Failed to create issue: {response.json().get('message')}")
        except Exception as e:
            st.error(f"Error: {e}")




