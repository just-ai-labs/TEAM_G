Title: Added CRUD Functionality Using Streamlit and GraphQL
Description:
This pull request introduces a Streamlit-based frontend integrated with a GraphQL API to perform CRUD operations on the database. The changes provide an interactive and user-friendly interface for managing data efficiently while leveraging GraphQL's flexibility for backend queries.

Key Changes:
Developed a Streamlit frontend:

Added dynamic input forms for user interaction.
Displayed database entries using responsive tables.
Included real-time feedback for successful CRUD operations.
Integrated GraphQL API:

Created queries and mutations for database operations.
Established communication between the frontend and GraphQL API.
Configured MongoDB:

Enabled seamless storage and retrieval of project and team member data.
Implemented CRUD functionalities:

Create: Add new projects and team members.
Read: Fetch project details or all entries.
Update: Modify project names or team member roles.
Delete: Remove projects or team members.
Testing and Validation:
Verified all CRUD operations via the Streamlit UI.
Ensured GraphQL API responded correctly to queries and mutations.
Checked database consistency after every operation.
Next Steps:
Review the codebase for further optimization.
Add additional features (e.g., user authentication) if required.

