# Slite Meeting Notes Agent

## Overview
This application is designed to manage and process meeting notes using various AI and machine learning tools. It leverages several libraries and frameworks to provide a robust backend for handling meeting data.

## Prerequisites
- Python 3.8 or higher
- pip (Python package installer)
- Node.js and npm (for the frontend)

## Installation

### Backend

1. **Clone the repository:**
    ```sh
    git clone https://github.com/yourusername/Slite-MeetingNotes-Agent.git
    cd Slite-MeetingNotes-Agent/Backend
    ```

2. **Create a virtual environment:**
    ```sh
    python -m venv venv
    ```

3. **Activate the virtual environment:**
    - On Windows:
        ```sh
        venv\Scripts\activate
        ```
    - On macOS/Linux:
        ```sh
        source venv/bin/activate
        ```

4. **Install the required packages:**
    ```sh
    pip install -r requirements.txt
    ```

### Frontend

1. **Navigate to the frontend directory:**
    ```sh
    cd ../Frontend
    ```

2. **Install the required packages:**
    ```sh
    npm install
    ```

## Configuration

1. **Create a `.env` file in the root directory and add the necessary environment variables:**
    ```env
    OPENAI_API_KEY=your_openai_api_key
    SLITE_API_KEY=your_slite_api_key
    LOG_LEVEL="DEBUG"  # Optional, defaults to INFO
    CACHE_TTL="300"
    ```

## Running the Application

### Backend

1. **Start the FastAPI server:**
    ```sh
    uvicorn server:app --reload
    ```

2. **Access the backend application:**
    Open your web browser and go to `http://127.0.0.1:8000`.

### Frontend

1. **Start the frontend development server:**
    ```sh
    npm run dev
    ```

2. **Access the frontend application:**
    Open your web browser and go to `http://localhost:3000`.


## Contributing
If you would like to contribute to this project, please fork the repository and submit a pull request.

## License
This project is licensed under the MIT License.