import os
import logging
import asyncio
import time
import random
from datetime import datetime
from typing import List, Dict, Any, Optional
from functools import partial
from langchain_google_genai import ChatGoogleGenerativeAI
import google.generativeai as genai
from langchain.agents import AgentType, initialize_agent, Tool
from langchain.memory import ConversationSummaryBufferMemory
from langchain.prompts import MessagesPlaceholder
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate
from langchain.tools import StructuredTool
from pydantic import BaseModel, Field
from note_manager import NoteManager, SliteAPI
from models import MeetingNote, FolderStructure
import json
import traceback
from langchain_community.chat_models import ChatOpenAI  # Updated import

logger = logging.getLogger(__name__)

class SliteTools:
    """Tools for interacting with Slite"""

    def __init__(self, api: SliteAPI):
        self.api = api
        self._last_note_id = None  # Store the ID of the last created/accessed note
        self._last_folder_id = None  # Store the ID of the last created/accessed folder
        self._existing_notes_cache = {}  # Add cache initialization
        self._selected_document = None  # Add selected document tracking
        self._folder_cache = {}  # Add folder cache

    @property
    def last_note_id(self):
        """Get the ID of the last created/accessed note"""
        return self._last_note_id
        
    @property
    def last_folder_id(self):
        """Get the ID of the last created/accessed folder"""
        return self._last_folder_id

    def _sanitize_content(self, content: str) -> str:
        """Sanitize and format content for Slite API"""
        if not content:
            return ""
        content = content.replace('\x00', '')
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        if not content.endswith('\n'):
            content += '\n'
        return content

    async def _find_existing_note(self, title: str) -> Optional[Dict[str, Any]]:
        """Find existing note by title, searching recursively through folders"""
        try:
            # Clean up the title by removing quotes
            clean_title = title.strip("'\"").strip()
            logger.info(f"Searching for note with title: {clean_title}")

            # First try global search with proper params per API docs
            search_response = await self.api._make_request(
                method="GET",
                endpoint="/search-notes",
                params={
                    "query": clean_title,
                    "hitsPerPage": 100,
                    "highlightPreTag": "",
                    "highlightPostTag": ""
                }
            )

            # Check hits from global search
            hits = search_response.get('hits', [])
            for hit in hits:
                if hit.get('title', '').lower() == clean_title.lower():
                    logger.info(f"Found note globally: {hit.get('title')}")
                    return hit

            # If not found globally, search in each folder
            folders_response = await self.api._make_request(
                method="GET",
                endpoint="/search-notes",
                params={
                    "query": "",
                    "type": "folder",
                    "hitsPerPage": 100
                }
            )

            folders = folders_response.get('hits', [])
            for folder in folders:
                folder_id = folder.get('id')
                if folder_id:
                    # Search within each folder with proper parentNoteId
                    folder_results = await self.api._make_request(
                        method="GET",
                        endpoint="/search-notes",
                        params={
                            "query": clean_title,
                            "parentNoteId": folder_id,
                            "hitsPerPage": 100
                        }
                    )

                    folder_hits = folder_results.get('hits', [])
                    for note in folder_hits:
                        if note.get('title', '').lower() == clean_title.lower():
                            logger.info(f"Found note in folder {folder.get('title')}: {note.get('title')}")
                            return note

            logger.info(f"Note '{clean_title}' not found in any location")
            return None

        except Exception as e:
            logger.error(f"Error finding existing note: {str(e)}")
            return None

    async def _get_note_content(self, note_id: str) -> Optional[str]:
        """Get note content with caching"""
        try:
            if (note_id in self._existing_notes_cache):
                return self._existing_notes_cache[note_id]['content']
            
            note = await self.api.get_note_async(note_id)
            if note:
                self._existing_notes_cache[note_id] = {
                    'content': note.get('markdown', ''),
                    'title': note.get('title', '')
                }
                return note.get('markdown', '')
            return None
        except Exception as e:
            logger.error(f"Error getting note content: {str(e)}")
            return None
        
    async def update_or_create_note(self, title: str, content: str, append: bool = False) -> str:
        """Update existing note or create new one if doesn't exist"""
        try:
            # Ensure API session is active
            if not self.api._session_active:
                await self.api.__aenter__()
                
            content = self._sanitize_content(content)
            clean_title = title.strip("'\"").strip()
            
            # First try to find the exact note by title
            existing_note = await self._find_existing_note(clean_title)
            
            if existing_note:
                note_id = existing_note['id']
                logger.info(f"Found existing note with title '{clean_title}' (ID: {note_id})")

                # Get existing content if appending
                if append:
                    existing_content = await self._get_note_content(note_id)
                    if existing_content:
                        content = f"{existing_content.rstrip()}\n\n{content}"

                # Update the note using proper API format
                data = {
                    "markdown": content,
                    "attributes": []
                }

                result = await self.api.update_note_async(
                    note_id=note_id,
                    content=data["markdown"],
                    append=append
                )

                if result and result.get("status") == "success":
                    self._last_note_id = note_id
                    self._existing_notes_cache[note_id] = {
                        'content': content,
                        'title': title
                    }
                    
                    return json.dumps({
                        "status": "success",
                        "message": f"Successfully {'appended to' if append else 'updated'} note: {title}",
                        "note_id": note_id,
                        "action": "updated"
                    }, indent=2)
            else:
                # Create new note with proper API format
                data = {
                    "title": clean_title,
                    "markdown": content,
                    "attributes": []
                }
                
                result = await self.api.create_note_async(
                    title=clean_title,
                    content=content
                )
                
                if result:
                    self._last_note_id = result.get('id')
                    return json.dumps({
                        "status": "success",
                        "message": f"Created new note: {title}",
                        "note_id": result.get('id'),
                        "action": "created"
                    }, indent=2)

            return json.dumps({
                "status": "error",
                "message": "Failed to update or create note"
            }, indent=2)

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error in update_or_create_note: {error_msg}")
            logger.error(traceback.format_exc())
            return json.dumps({
                "status": "error", 
                "message": f"Error updating/creating note: {error_msg}",
                "details": traceback.format_exc()
            }, indent=2)

    async def process_multiline_input(self) -> str:
        """Process multiline input from terminal"""
        print("Enter/paste your content. Press Ctrl+D (Unix) or Ctrl+Z (Windows) on a new line to finish:")
        content_lines = []
        try:
            while True:
                line = input()
                content_lines.append(line)
        except EOFError:
            pass
        
        return '\n'.join(content_lines)

    async def create_note(self, title: str, content: str, tags: Optional[List[str]] = None) -> str:
        """Create a new note"""
        try:
            result = await self.api.create_note_async(title=title, content=content)
            if result and isinstance(result, dict):
                self._last_note_id = result.get('id')  # Store the note ID
            return json.dumps({"status": "success", "note": result}, indent=2)
        except Exception as e:
            logger.error(f"Error creating note: {str(e)}")
            return f"Error creating note: {str(e)}"

    async def search_notes(self, query: str) -> str:
        """Search for notes"""
        try:
            results = await self.api.search_notes_async(query)
            if results and isinstance(results, list) and len(results) > 0:
                self._last_note_id = results[0].get('id')  # Store the first result's ID
            return json.dumps({"status": "success", "results": results}, indent=2)
        except Exception as e:
            logger.error(f"Error searching notes: {str(e)}")
            return f"Error searching notes: {str(e)}"

    async def update_note(self, note_id: str, content: str, append: bool = False) -> str:
        """Update or append to an existing note."""
        try:
            # Sanitize content
            content = self._sanitize_content(content)
            
            # Get existing note content if appending
            if append:
                existing_content = await self._get_note_content(note_id)
                if existing_content:
                    content = f"{existing_content.rstrip()}\n\n{content}"

            # Format the update payload according to Slite API specs
            update_payload = {
                "markdown": content,  # Use markdown format for content
                "attributes": []  # Keep any existing attributes
            }

            # Update the note using PUT request
            result = await self.api.update_note_async(
                note_id=note_id,
                content=update_payload["markdown"],
                append=append
            )
            
            if result.get("status") == "error":
                return json.dumps(result, indent=2)
            
            # Update cache
            self._existing_notes_cache[note_id] = {
                'content': content,
                'title': result.get('title', '')
            }
            
            return json.dumps({
                "status": "success",
                "message": f"Successfully {'appended to' if append else 'updated'} note {note_id}",
                "data": result
            }, indent=2)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error updating note: {error_msg}")
            logger.error(traceback.format_exc())
            return json.dumps({
                "status": "error",
                "message": f"Error updating note: {error_msg}",
                "details": traceback.format_exc()
            }, indent=2)

    async def summarize_note(self, note_id: str) -> str:
        """Generate a summary of a note's content"""
        try:
            note = await self.api.get_note_async(note_id)
            if not note:
                return "Note not found"
            return json.dumps({
                "status": "success",
                "summary": f"Summary of note '{note['title']}': {note['content'][:200]}..."
            }, indent=2)
        except Exception as e:
            logger.error(f"Error summarizing note: {str(e)}")
            return f"Error summarizing note: {str(e)}"

    async def delete_note(self, note_id: str = None) -> str:
        """Delete a note by ID or title"""
        try:
            # If no note_id provided, use the last accessed note
            if not note_id and self._last_note_id:
                note_id = self._last_note_id
                logger.info(f"Using last accessed note ID: {note_id}")
            elif not note_id:
                return json.dumps({
                    "status": "error",
                    "message": "No note ID provided and no last accessed note found"
                }, indent=2)

            original_input = note_id  # Store original input for error messages
            found_by_title = False

            # If note_id doesn't look like a Slite ID, try to search for it by title
            if not note_id.startswith('n_'):
                try:
                    logger.info(f"Searching for note with title: {note_id}")
                    search_results = await self.api.search_notes_async(note_id)
                    
                    if search_results:
                        # Try exact match first
                        for note in search_results:
                            if note.get('title', '').lower() == note_id.lower():
                                note_id = note.get('id')
                                found_by_title = True
                                logger.info(f"Found exact match for title '{original_input}' with ID: {note_id}")
                                break
                        
                        # If no exact match, try partial match
                        if not found_by_title and search_results[0].get('id'):
                            note_id = search_results[0].get('id')
                            found_by_title = True
                            logger.info(f"Using best match for title '{original_input}' with ID: {note_id}")
                    
                    if not found_by_title:
                        return json.dumps({
                            "status": "error",
                            "message": f"Could not find note with title: {original_input}"
                        }, indent=2)
                        
                except Exception as e:
                    logger.error(f"Error searching for note by title: {str(e)}")
                    return json.dumps({
                        "status": "error",
                        "message": f"Error searching for note '{original_input}': {str(e)}"
                    }, indent=2)

            # Delete the note
            result = await self.api.delete_note_async(note_id)
            
            # Check the result
            if result.get("status") == "error":
                return json.dumps(result, indent=2)
                
            # Clear the last note ID if we just deleted it
            if self._last_note_id == note_id:
                self._last_note_id = None
                
            success_msg = f"Note {original_input if found_by_title else note_id} deleted successfully"
            logger.info(success_msg)
            return json.dumps({
                "status": "success",
                "message": success_msg,
                "note_id": note_id
            }, indent=2)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error deleting note: {error_msg}")
            return json.dumps({
                "status": "error",
                "message": f"Error deleting note: {error_msg}"
            }, indent=2)

    async def create_folder(self, name: str, description: str = "") -> str:
        """Create a new folder if it doesn't exist"""
        try:
            # First check folder cache
            folder_name_lower = name.lower()
            if folder_name_lower in self._folder_cache:
                logger.info(f"Using cached folder: {name}")
                return json.dumps({
                    "status": "success", 
                    "message": "Using existing folder",
                    "folder": self._folder_cache[folder_name_lower]
                }, indent=2)
                
            # Check if folder exists via search
            existing_folder = await self.api.search_folder_by_name(name)
            if existing_folder:
                self._folder_cache[folder_name_lower] = existing_folder
                logger.info(f"Using existing folder: {name}")
                return json.dumps({
                    "status": "success",
                    "message": "Using existing folder",
                    "folder": existing_folder
                }, indent=2)

            # Create new folder only if it doesn't exist
            result = await self.api.create_folder(name=name, description=description)
            if result:
                self._folder_cache[folder_name_lower] = result
                logger.info(f"Created new folder: {name}")
            return json.dumps({"status": "success", "folder": result}, indent=2)
            
        except Exception as e:
            logger.error(f"Error creating folder: {str(e)}")
            return json.dumps({
                "status": "error",
                "message": f"Error creating folder: {str(e)}"
            }, indent=2)

    async def create_note_in_folder(self, title: str, content: str, folder_name: str = None, tags: Optional[List[str]] = None) -> str:
        """Create a new note in a specific folder"""
        try:
            folder_id = None
            
            if (folder_name):
                # Use cached folder if available
                folder_name_lower = folder_name.lower()
                if folder_name_lower in self._folder_cache:
                    folder_id = self._folder_cache[folder_name_lower].get('id')
                    logger.info(f"Using cached folder: {folder_name}")
                else:
                    # Search for existing folder
                    existing_folder = await self.api.search_folder_by_name(folder_name)
                    if existing_folder:
                        folder_id = existing_folder.get('id')
                        self._folder_cache[folder_name_lower] = existing_folder
                        logger.info(f"Found existing folder: {folder_name}")
                    else:
                        # Create new folder if needed
                        logger.info(f"Creating new folder: {folder_name}")
                        folder_result = await self.api.create_folder(name=folder_name)
                        folder_id = folder_result.get('id')
                        self._folder_cache[folder_name_lower] = folder_result

            # Create the note with required fields per API docs
            data = {
                "title": title,
                "markdown": f"""# {title}

This document was created in the {folder_name} folder.

## Content
{content if content else 'Add your content here...'}""",
                "attributes": [],  # Required by API
                "parentNoteId": folder_id if folder_id else None
            }

            logger.info(f"Creating note '{title}' in folder '{folder_name}'")
            result = await self.api._make_request(
                method="POST",
                endpoint="/notes",
                json=data
            )

            if result:
                self._last_note_id = result.get('id')
                return json.dumps({"status": "success", "note": result}, indent=2)

            return json.dumps({"status": "error", "message": "Failed to create note"}, indent=2)

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error creating note in folder: {error_msg}")
            return json.dumps({
                "status": "error",
                "message": f"Error creating note in folder: {error_msg}"
            }, indent=2)

    async def rename_folder(self, folder_name: str, new_name: str) -> str:
        """Rename a folder"""
        try:
            # Find the folder by name
            folder = await self.api.search_folder_by_name(folder_name)
            if not folder:
                return json.dumps({"status": "error", "message": f"Folder '{folder_name}' not found"})
            
            folder_id = folder.get('id')
            result = await self.api.rename_folder(folder_id, new_name)
            return json.dumps({"status": "success", "folder": result}, indent=2)
        except Exception as e:
            logger.error(f"Error renaming folder: {str(e)}")
            return f"Error renaming folder: {str(e)}"

    async def rename_note(self, note_title: str, new_title: str) -> str:
        """Rename a note"""
        try:
            # Search for the note
            search_results = await self.api.search_notes_async(note_title)
            if not search_results:
                return json.dumps({"status": "error", "message": f"Note '{note_title}' not found"})
            
            # Find exact match
            note_id = None
            for note in search_results:
                if note.get('title', '').lower() == note_title.lower():
                    note_id = note.get('id')
                    break
            
            if not note_id:
                return json.dumps({"status": "error", "message": f"Note '{note_title}' not found"})
            
            result = await self.api.rename_document(note_id, new_title)
            return json.dumps({"status": "success", "note": result}, indent=2)
        except Exception as e:
            logger.error(f"Error renaming note: {str(e)}")
            return f"Error renaming note: {str(e)}"

class SearchNotesInput(BaseModel):
    query: str = Field(..., description="The search query to find relevant notes")

class CreateNoteInput(BaseModel):
    title: str = Field(..., description="The title of the note")
    content: str = Field(..., description="The content of the note")
    tags: Optional[List[str]] = Field(None, description="Optional tags for the note")

class UpdateNoteInput(BaseModel):
    note_id: str = Field(..., description="The ID of the note to update")
    content: str = Field(..., description="The new content for the note")
    append: bool = Field(False, description="Whether to append the content to the existing note")

class SummarizeNoteInput(BaseModel):
    note_id: str = Field(..., description="The ID of the note to summarize")

class DeleteNoteInput(BaseModel):
    note_id: str = Field(..., description="The ID of the note to delete")

class CreateFolderInput(BaseModel):
    name: str = Field(..., description="The name of the folder")
    description: str = Field("", description="Optional description for the folder")

class CreateNoteInFolderInput(BaseModel):
    title: str = Field(..., description="The title of the note")
    content: str = Field(..., description="The content of the note")
    folder_name: str = Field(None, description="Optional name of the folder to create the note in")
    tags: Optional[List[str]] = Field(None, description="Optional tags for the note")

class RenameFolderInput(BaseModel):
    folder_name: str = Field(..., description="The current name of the folder")
    new_name: str = Field(..., description="The new name for the folder")

class RenameNoteInput(BaseModel):
    note_title: str = Field(..., description="The current title of the note")
    new_title: str = Field(..., description="The new title for the note")

class SliteAgent:
    """LangChain agent for interacting with Slite with enhanced features"""

    def __init__(self, api_key: str, openai_api_key: str = None):
        """Initialize the SliteAgent with API keys"""
        self.api_key = api_key
        self.openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        if not self.openai_api_key:
            raise ValueError("OpenAI API key must be provided")
        
        self.api = SliteAPI(self.api_key)
        self.tools = None
        
        # Update memory to use OpenAI
        llm = ChatOpenAI(
            model_name="gpt-4",
            temperature=0,
            openai_api_key=self.openai_api_key
        )
        
        self.memory = ConversationSummaryBufferMemory(
            llm=llm,
            max_token_limit=500,
            memory_key="chat_history",
            return_messages=True
        )
        
        self.agent_executor = None
        self._session_initialized = False
        self._session_in_use = False
        self._keep_session_alive = True
        self._force_cleanup = False

        # Initialize rate limiting params
        self._request_count = 0
        self._last_request_time = 0
        self._max_requests_per_minute = 20
        
        # Update LLM config
        self.llm = ChatOpenAI(
            model_name="gpt-4",
            temperature=0,
            openai_api_key=self.openai_api_key,
            request_timeout=30
        )

    async def _check_rate_limit(self):
        """Enforce rate limiting"""
        current_time = time.time()
        if current_time - self._last_request_time < 60:  # Within a minute
            if self._request_count >= self._max_requests_per_minute:
                wait_time = 60 - (current_time - self._last_request_time)
                logger.warning(f"Rate limit reached, waiting {wait_time:.1f} seconds")
                await asyncio.sleep(wait_time)
                self._request_count = 0
                self._last_request_time = current_time
        else:
            # Reset for new minute
            self._request_count = 0
            self._last_request_time = current_time
            
        self._request_count += 1

    async def _ensure_session(self):
        """Ensure API session is initialized"""
        await self.api.ensure_session()
        self._session_initialized = True

    async def _release_session(self):
        """Release but don't close the session"""
        self._session_in_use = False

    async def initialize_agent(self):
        """Initialize the agent with tools and memory"""
        try:
            if not self.agent_executor:
                # Initialize API session
                await self._ensure_session()
                
                # Initialize tools
                self.tools = SliteTools(self.api)
                
                # Create tools list
                tools = [
                    StructuredTool.from_function(
                        func=self.tools.search_notes,
                        name="SearchNotes",
                        description="Search for notes using a query.",
                        args_schema=SearchNotesInput,
                        coroutine=self.tools.search_notes
                    ),
                    StructuredTool.from_function(
                        func=self.tools.create_note,
                        name="CreateNote",
                        description="Create a new note with title, content, and optional tags.",
                        args_schema=CreateNoteInput,
                        coroutine=self.tools.create_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.update_note,
                        name="UpdateNote",
                        description="Update or append to an existing note.",
                        args_schema=UpdateNoteInput,
                        coroutine=self.tools.update_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.summarize_note,
                        name="SummarizeNote",
                        description="Generate a summary of a note's content.",
                        args_schema=SummarizeNoteInput,
                        coroutine=self.tools.summarize_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.delete_note,
                        name="DeleteNote",
                        description="Delete a note by ID or title.",
                        args_schema=DeleteNoteInput,
                        coroutine=self.tools.delete_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.create_folder,
                        name="CreateFolder",
                        description="Create a new folder.",
                        args_schema=CreateFolderInput,
                        coroutine=self.tools.create_folder
                    ),
                    StructuredTool.from_function(
                        func=self.tools.create_note_in_folder,
                        name="CreateNoteInFolder",
                        description="Create a new note in a specific folder with title, content, and optional tags.",
                        args_schema=CreateNoteInFolderInput,
                        coroutine=self.tools.create_note_in_folder
                    ),
                    StructuredTool.from_function(
                        func=self.tools.rename_folder,
                        name="RenameFolder",
                        description="Rename a folder.",
                        args_schema=RenameFolderInput,
                        coroutine=self.tools.rename_folder
                    ),
                    StructuredTool.from_function(
                        func=self.tools.rename_note,
                        name="RenameNote",
                        description="Rename a note.",
                        args_schema=RenameNoteInput,
                        coroutine=self.tools.rename_note
                    )
                ]
                
                system_prompt = """You are a helpful assistant that manages notes and folders in Slite.
                
                Available tools:
                1. SearchNotes:
                   - Search for notes using keywords
                   Example: {"query": "meeting notes"}
                
                2. UpdateNote:
                   - Update or append content to an existing note
                   Example: {"note_id": "123", "content": "New content", "append": false}
                
                3. DeleteNote:
                   - Delete a note by ID or title
                   Example: {"note_id": "123"}
                
                4. CreateFolder:
                   - Create a new folder with a given name and optional description
                   Example: {"name": "New Folder", "description": "This is a new folder"}
                
                5. CreateNoteInFolder:
                   - Create a new note in a specific folder with title, content, and optional tags
                   Example: {"title": "New Note", "content": "This is a new note", "folder_name": "Existing Folder", "tags": ["tag1", "tag2"]}
                
                6. RenameFolder:
                   - Rename a folder
                   Example: {"folder_name": "Old Folder", "new_name": "New Folder"}
                
                7. RenameNote:
                   - Rename a note
                   Example: {"note_title": "Old Note", "new_title": "New Note"}
                
                When the user asks to:
                1. Create a document in a folder:
                   - First check if the folder exists using the folder name
                   - If it exists, create the note in that folder
                   - If it doesn't exist, create the folder first, then create the note
                
                2. "Add content" or "update" a note:
                   - Use UpdateNote with append=true on the existing note
                   - If no note ID provided, use the last accessed note
                
                3. "Delete" a note:
                   - Use DeleteNote on the specified note
                   - If no note ID provided, use the last accessed note
                   - Confirm the deletion was successful
                
                4. "Create a new folder":
                   - Use CreateFolder to create a new folder with a given name and optional description
                   
                5. "Create a new note in a folder":
                   - Use CreateNoteInFolder to create a new note in a specific folder
                   - Specify the folder name, not the ID
                   - Always provide initial content like "# Title\n\nInitial content for the document"
                   - The folder will be found or created automatically
                
                6. "Rename a folder":
                   - Use RenameFolder to rename a folder
                
                7. "Rename a note":
                   - Use RenameNote to rename a note"""
                
                human_message = HumanMessagePromptTemplate.from_template("{input}\n\nCurrent conversation:\n{agent_scratchpad}")
                chat_prompt = ChatPromptTemplate.from_messages([
                    SystemMessagePromptTemplate.from_template(system_prompt),
                    MessagesPlaceholder(variable_name="chat_history"),
                    human_message
                ])

                self.agent_executor = initialize_agent(
                    tools=tools,
                    llm=ChatOpenAI(
                        model_name="gpt-4",
                        temperature=0,
                        openai_api_key=self.openai_api_key
                    ),
                    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
                    verbose=True,
                    memory=self.memory,
                    agent_kwargs={
                        "system_message": system_prompt,
                        "input_variables": ["input", "agent_scratchpad", "chat_history"]
                    }
                )
        except Exception as e:
            logger.error(f"Error initializing agent: {str(e)}")
            raise
    
    async def process_query(self, query: str) -> str:
        """Process a user query and return the response"""
        try:
            await self._check_rate_limit()
            await self._ensure_session()
            
            if not self.agent_executor:
                await self.initialize_agent()
            
            # Check if this is an update operation
            query_lower = query.lower().strip()
            if query_lower.startswith("update ") or query_lower.startswith("add content to "):
                # Extract document title - handle both quoted and unquoted titles
                title = None
                if '"' in query:
                    # Extract title between quotes
                    try:
                        title = query.split('"')[1]
                    except IndexError:
                        return "Invalid format. Please provide the document title in quotes."
                else:
                    # Extract title after "update" or "add content to"
                    title = query_lower.replace("update ", "").replace("add content to ", "").strip()
                
                if not title:
                    return "Please provide a document title to update."
                
                # Prompt for multiline content input
                print("\nEnter/paste your content (Press Ctrl+D on Unix or Ctrl+Z on Windows + Enter on a new line when done):")
                content_lines = []
                while True:
                    try:
                        line = input()
                        content_lines.append(line)
                    except EOFError:
                        break
                
                content = "\n".join(content_lines)
                
                if not content.strip():
                    return "No content provided. Update cancelled."
                
                # Search for the note and update it
                result = await self.tools.update_or_create_note(
                    title=title,
                    content=content,
                    append=True  # Set to True to append content instead of overwriting
                )
                
                await self._release_session()
                return f"Document update result:\n{result}"

            # Handle other types of queries through normal agent flow
            response = await self.agent_executor.arun(input=query)
            await self._release_session()
            return response
                
        except Exception as e:
            if "429" in str(e):
                wait_time = random.uniform(2, 5)
                logger.warning(f"Rate limit hit, waiting {wait_time:.1f} seconds")
                await asyncio.sleep(wait_time)
                return await self.process_query(query)
            logger.error(f"Error processing query: {str(e)}")
            logger.error(traceback.format_exc())
            return f"Error processing query: {str(e)}"

    async def cleanup(self):
        """Cleanup resources only when explicitly called"""
        if self._force_cleanup:
            await self.api.close(force=True)
            self._session_initialized = False

    async def close(self):
        """Explicitly close the agent and its resources"""
        self._keep_session_alive = False
        self._force_cleanup = True
        await self.cleanup()
        self.api._force_cleanup = True
        await self.api.close(force=True)

    def __del__(self):
        """Ensure cleanup on deletion"""
        if self._session_initialized:
            import asyncio
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self.cleanup())
                else:
                    loop.run_until_complete(self.cleanup())
            except Exception:
                pass

class SliteNoteManager:
    def __init__(self):
        self.api_key = os.getenv('SLITE_API_KEY')
        self.note_manager = NoteManager(self.api_key)

    def process_meeting_notes(self, content: str) -> dict:
        """Process meeting notes and create a note in Slite"""
        try:
            # Extract title from content (assuming markdown format)
            title = "AI Agent Introduction Meeting"
            
            # Create the note
            note = self.note_manager.create_note(title=title, content=content)
            return note
            
        except Exception as e:
            logger.error(f"Error processing meeting notes: {str(e)}")
            raise

    def create_folder_structure(self) -> dict:
        """Create a basic folder structure for organizing notes"""
        try:
            # Create main folder for meetings
            folder = self.note_manager.create_folder(
                name="AI Agent Meetings",
                description="Meeting notes about AI Agent discussions"
            )
            return folder
            
        except Exception as e:
            logger.error(f"Error creating folder structure: {str(e)}")
            raise

    def search_and_update_notes(self, query: str) -> list:
        """Search for notes and update them if needed"""
        try:
            # Search for notes
            results = self.note_manager.search_notes(query)
            return results
            
        except Exception as e:
            logger.error(f"Error searching notes: {str(e)}")
            raise

# Update run_async function to handle cleanup
def run_async(coro):
    """Run an async function in a synchronous context"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    async def wrapped_coro():
        agent = None
        try:
            if isinstance(coro, SliteAgent):
                agent = coro
                await agent._ensure_session()
                return agent
            else:
                return await coro
        finally:
            if agent:
                await agent.cleanup()
    
    return loop.run_until_complete(wrapped_coro())