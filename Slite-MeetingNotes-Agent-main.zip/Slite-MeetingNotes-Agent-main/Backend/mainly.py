import os
import logging
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from functools import partial
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI  # Add this import
import google.generativeai as genai  # Add this import
from google.api_core import exceptions as google_exceptions  # Add this import
from google.api_core import exceptions, retry
import google.api_core
from langchain.agents import AgentType, initialize_agent, Tool
from langchain.memory import ConversationSummaryBufferMemory
from langchain.prompts import MessagesPlaceholder
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate
from langchain.tools import StructuredTool
from pydantic import BaseModel, Field
from note_manager import NoteManager, SliteAPI
from models import MeetingNote, FolderStructure
import json
import traceback
from google.api_core import retry
import tenacity
import time

logger = logging.getLogger(__name__)

class SliteTools:
    """Tools for interacting with Slite"""

    def __init__(self, api: SliteAPI):
        self.api = api
        self._last_note_id = None  # Store the ID of the last created/accessed note
        self._last_folder_id = None  # Store the ID of the last created/accessed folder
        self._existing_notes_cache = {}  # Add cache initialization
        self._folder_cache = {}  # Add folder cache

    @property
    def last_note_id(self):
        """Get the ID of the last created/accessed note"""
        return self._last_note_id
        
    @property
    def last_folder_id(self):
        """Get the ID of the last created/accessed folder"""
        return self._last_folder_id

    def _sanitize_content(self, content: str) -> str:
        """Sanitize and format content for Slite API"""
        if not content:
            return ""
        content = content.replace('\x00', '')
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        if not content.endswith('\n'):
            content += '\n'
        return content

    async def _find_existing_note(self, title: str) -> Optional[Dict[str, Any]]:
        """Find existing note by title"""
        try:
            search_results = await self.api.search_notes_async(title)
            if search_results:
                for note in search_results:
                    if note.get('title', '').lower() == title.lower():
                        return note
            return None
        except Exception as e:
            logger.error(f"Error finding existing note: {str(e)}")
            return None

    async def _get_note_content(self, note_id: str) -> Optional[str]:
        """Get note content with caching"""
        try:
            if (note_id in self._existing_notes_cache):
                return self._existing_notes_cache[note_id]['content']
            
            note = await self.api.get_note_async(note_id)
            if note:
                self._existing_notes_cache[note_id] = {
                    'content': note.get('markdown', ''),
                    'title': note.get('title', '')
                }
                return note.get('markdown', '')
            return None
        except Exception as e:
            logger.error(f"Error getting note content: {str(e)}")
            return None
        
    async def update_or_create_note(self, title: str, content: str, append: bool = False) -> str:
        """Update existing note or create new one if doesn't exist"""
        try:
            # Ensure API session is active
            if not self.api._session_active:
                await self.api.__aenter__()
                
            content = self._sanitize_content(content)
            
            # First try to find the exact note by title
            existing_note = await self._find_existing_note(title)
            
            if existing_note:
                note_id = existing_note['id']
                logger.info(f"Found existing note with title '{title}' (ID: {note_id})")

                # Get existing content if appending
                if append:
                    existing_content = await self._get_note_content(note_id)
                    if existing_content:
                        content = f"{existing_content.rstrip()}\n\n{content}"

                # Update the note using the note ID
                result = await self.api.update_note_async(
                    note_id=note_id,
                    content=content,
                    append=append
                )

                if result and result.get("status") == "success":
                    self._last_note_id = note_id
                    self._existing_notes_cache[note_id] = {
                        'content': content,
                        'title': title
                    }
                    
                    return json.dumps({
                        "status": "success",
                        "message": f"Successfully {'appended to' if append else 'updated'} note: {title}",
                        "note_id": note_id,
                        "action": "updated"
                    }, indent=2)
            else:
                # Create new note
                logger.info(f"Note with title '{title}' not found, creating new note")
                result = await self.api.create_note_async(
                    title=title,
                    content=content
                )
                
                if result:
                    self._last_note_id = result.get('id')
                    return json.dumps({
                        "status": "success",
                        "message": f"Created new note: {title}",
                        "note_id": result.get('id'),
                        "action": "created"
                    }, indent=2)

            return json.dumps({
                "status": "error",
                "message": "Failed to update or create note"
            }, indent=2)

        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error in update_or_create_note: {error_msg}")
            logger.error(traceback.format_exc())
            return json.dumps({
                "status": "error", 
                "message": f"Error updating/creating note: {error_msg}",
                "details": traceback.format_exc()
            }, indent=2)

    async def process_multiline_input(self) -> str:
        """Process multiline input from terminal"""
        print("Enter/paste your content. Press Ctrl+D (Unix) or Ctrl+Z (Windows) on a new line to finish:")
        content_lines = []
        try:
            while True:
                line = input()
                content_lines.append(line)
        except EOFError:
            pass
        
        return '\n'.join(content_lines)

    async def create_note(self, title: str, content: str, tags: Optional[List[str]] = None) -> str:
        """Create a new note"""
        try:
            result = await self.api.create_note_async(title=title, content=content)
            if result and isinstance(result, dict):
                self._last_note_id = result.get('id')  # Store the note ID
            return json.dumps({"status": "success", "note": result}, indent=2)
        except Exception as e:
            logger.error(f"Error creating note: {str(e)}")
            return f"Error creating note: {str(e)}"

    async def search_notes(self, query: str) -> str:
        """Search for notes"""
        try:
            results = await self.api.search_notes_async(query)
            if results and isinstance(results, list) and len(results) > 0:
                self._last_note_id = results[0].get('id')  # Store the first result's ID
            return json.dumps({"status": "success", "results": results}, indent=2)
        except Exception as e:
            logger.error(f"Error searching notes: {str(e)}")
            return f"Error searching notes: {str(e)}"

    async def update_note(self, note_id: str, content: str, append: bool = False) -> str:
        """Update or append to an existing note."""
        try:
            # Sanitize content
            content = self._sanitize_content(content)
            
            # Get existing note content if appending
            if append:
                existing_content = await self._get_note_content(note_id)
                if existing_content:
                    content = f"{existing_content.rstrip()}\n\n{content}"

            # Format the update payload according to Slite API specs
            update_payload = {
                "markdown": content,  # Use markdown format for content
                "attributes": []  # Keep any existing attributes
            }

            # Update the note using PUT request
            result = await self.api.update_note_async(
                note_id=note_id,
                content=update_payload["markdown"],
                append=append
            )
            
            if result.get("status") == "error":
                return json.dumps(result, indent=2)
            
            # Update cache
            self._existing_notes_cache[note_id] = {
                'content': content,
                'title': result.get('title', '')
            }
            
            return json.dumps({
                "status": "success",
                "message": f"Successfully {'appended to' if append else 'updated'} note {note_id}",
                "data": result
            }, indent=2)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error updating note: {error_msg}")
            logger.error(traceback.format_exc())
            return json.dumps({
                "status": "error",
                "message": f"Error updating note: {error_msg}",
                "details": traceback.format_exc()
            }, indent=2)

    async def summarize_note(self, note_id: str) -> str:
        """Generate a summary of a note's content"""
        try:
            note = await self.api.get_note_async(note_id)
            if not note:
                return "Note not found"
            return json.dumps({
                "status": "success",
                "summary": f"Summary of note '{note['title']}': {note['content'][:200]}..."
            }, indent=2)
        except Exception as e:
            logger.error(f"Error summarizing note: {str(e)}")
            return f"Error summarizing note: {str(e)}"

    async def delete_note(self, note_id: str = None) -> str:
        """Delete a note by ID or title"""
        try:
            # If no note_id provided, use the last accessed note
            if not note_id and self._last_note_id:
                note_id = self._last_note_id
                logger.info(f"Using last accessed note ID: {note_id}")
            elif not note_id:
                return json.dumps({
                    "status": "error",
                    "message": "No note ID provided and no last accessed note found"
                }, indent=2)

            original_input = note_id  # Store original input for error messages
            found_by_title = False

            # If note_id doesn't look like a Slite ID, try to search for it by title
            if not note_id.startswith('n_'):
                try:
                    logger.info(f"Searching for note with title: {note_id}")
                    search_results = await self.api.search_notes_async(note_id)
                    
                    if search_results:
                        # Try exact match first
                        for note in search_results:
                            if note.get('title', '').lower() == note_id.lower():
                                note_id = note.get('id')
                                found_by_title = True
                                logger.info(f"Found exact match for title '{original_input}' with ID: {note_id}")
                                break
                        
                        # If no exact match, try partial match
                        if not found_by_title and search_results[0].get('id'):
                            note_id = search_results[0].get('id')
                            found_by_title = True
                            logger.info(f"Using best match for title '{original_input}' with ID: {note_id}")
                    
                    if not found_by_title:
                        return json.dumps({
                            "status": "error",
                            "message": f"Could not find note with title: {original_input}"
                        }, indent=2)
                        
                except Exception as e:
                    logger.error(f"Error searching for note by title: {str(e)}")
                    return json.dumps({
                        "status": "error",
                        "message": f"Error searching for note '{original_input}': {str(e)}"
                    }, indent=2)

            # Delete the note
            result = await self.api.delete_note_async(note_id)
            
            # Check the result
            if result.get("status") == "error":
                return json.dumps(result, indent=2)
                
            # Clear the last note ID if we just deleted it
            if self._last_note_id == note_id:
                self._last_note_id = None
                
            success_msg = f"Note {original_input if found_by_title else note_id} deleted successfully"
            logger.info(success_msg)
            return json.dumps({
                "status": "success",
                "message": success_msg,
                "note_id": note_id
            }, indent=2)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error deleting note: {error_msg}")
            return json.dumps({
                "status": "error",
                "message": f"Error deleting note: {error_msg}"
            }, indent=2)

    async def _find_existing_folder(self, folder_name: str) -> Optional[Dict[str, Any]]:
        """Find existing folder by name with caching"""
        try:
            # Check cache first
            folder_name_lower = folder_name.lower()
            if folder_name_lower in self._folder_cache:
                logger.info(f"Found folder in cache: {folder_name}")
                return self._folder_cache[folder_name_lower]

            # Search using proper Slite API parameters per docs
            logger.info(f"Searching for folder: {folder_name}")
            response = await self.api._make_request(
                "GET",
                "/search-notes",
                params={
                    "query": folder_name,
                    "type": "folder",
                    "hitsPerPage": 10
                }
            )
            
            hits = response.get('hits', [])
            for hit in hits:
                if hit.get('title', '').lower() == folder_name_lower:
                    # Cache the found folder
                    self._folder_cache[folder_name_lower] = hit
                    logger.info(f"Found folder: {folder_name}")
                    return hit
                    
            logger.info(f"No folder found with name: {folder_name}")
            return None

        except Exception as e:
            logger.error(f"Error finding folder: {str(e)}")
            return None

    async def create_folder(self, name: str, description: str = "") -> str:
        """Create a new folder if it doesn't exist"""
        try:
            # First check if folder exists
            existing_folder = await self._find_existing_folder(name)
            if existing_folder:
                self._last_folder_id = existing_folder.get('id')
                logger.info(f"Using existing folder: {name}")
                return json.dumps({
                    "status": "success",
                    "message": "Using existing folder",
                    "folder": existing_folder
                }, indent=2)

            # Create new folder only if it doesn't exist
            data = {
                "title": name,
                "description": description,
                "type": "folder"
            }
            result = await self.api._make_request("POST", "/notes", json=data)
            
            if result:
                self._last_folder_id = result.get('id')
                # Cache the new folder
                self._folder_cache[name.lower()] = result
                logger.info(f"Created new folder: {name}")
                
            return json.dumps({"status": "success", "folder": result}, indent=2)
            
        except Exception as e:
            logger.error(f"Error creating folder: {str(e)}")
            return json.dumps({
                "status": "error",
                "message": f"Error creating folder: {str(e)}"
            }, indent=2)

    async def create_note_in_folder(self, title: str, content: str, folder_name: str = None, tags: Optional[List[str]] = None) -> str:
        """Create a new note in a specific folder"""
        try:
            folder_id = None
            
            if folder_name:
                # First check if folder exists
                existing_folder = await self._find_existing_folder(folder_name)
                if existing_folder:
                    folder_id = existing_folder.get('id')
                    logger.info(f"Using existing folder: {folder_name}")
                else:
                    # Create new folder if needed
                    logger.info(f"Creating new folder: {folder_name}")
                    folder_result = await self.api.create_folder(name=folder_name)
                    folder_id = folder_result.get('id')
                    self._folder_cache[folder_name.lower()] = folder_result

            # Ensure we have minimum content per API requirements
            if not content:
                content = "# New document"

            # Create note in folder using proper API format
            data = {
                "title": title,
                "markdown": content,
                "parentNoteId": folder_id,
                "attributes": []  # Required per API docs
            }
            
            logger.info(f"Creating note '{title}' in folder '{folder_name}'")
            result = await self.api._make_request("POST", "/notes", json=data)
            
            if result:
                self._last_note_id = result.get('id')
                return json.dumps({
                    "status": "success",
                    "message": f"Created note '{title}' in folder '{folder_name}'",
                    "note": result
                }, indent=2)
            
            return json.dumps({"status": "error", "message": "Failed to create note"}, indent=2)
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error creating note in folder: {error_msg}")
            return json.dumps({
                "status": "error",
                "message": f"Error creating note in folder: {error_msg}"
            }, indent=2)

    async def rename_folder(self, folder_name: str, new_name: str) -> str:
        """Rename a folder"""
        try:
            # Find the folder by name
            folder = await self.api.search_folder_by_name(folder_name)
            if not folder:
                return json.dumps({"status": "error", "message": f"Folder '{folder_name}' not found"})
            
            folder_id = folder.get('id')
            result = await self.api.rename_folder(folder_id, new_name)
            return json.dumps({"status": "success", "folder": result}, indent=2)
        except Exception as e:
            logger.error(f"Error renaming folder: {str(e)}")
            return f"Error renaming folder: {str(e)}"

    async def rename_note(self, note_title: str, new_title: str) -> str:
        """Rename a note"""
        try:
            # Search for the note
            search_results = await self.api.search_notes_async(note_title)
            if not search_results:
                return json.dumps({"status": "error", "message": f"Note '{note_title}' not found"})
            
            # Find exact match
            note_id = None
            for note in search_results:
                if note.get('title', '').lower() == note_title.lower():
                    note_id = note.get('id')
                    break
            
            if not note_id:
                return json.dumps({"status": "error", "message": f"Note '{note_title}' not found"})
            
            result = await self.api.rename_document(note_id, new_title)
            return json.dumps({"status": "success", "note": result}, indent=2)
        except Exception as e:
            logger.error(f"Error renaming note: {str(e)}")
            return f"Error renaming note: {str(e)}"

class SearchNotesInput(BaseModel):
    query: str = Field(..., description="The search query to find relevant notes")

class CreateNoteInput(BaseModel):
    title: str = Field(..., description="The title of the note")
    content: str = Field(..., description="The content of the note")
    tags: Optional[List[str]] = Field(None, description="Optional tags for the note")

class UpdateNoteInput(BaseModel):
    note_id: str = Field(..., description="The ID of the note to update")
    content: str = Field(..., description="The new content for the note")
    append: bool = Field(False, description="Whether to append the content to the existing note")

class SummarizeNoteInput(BaseModel):
    note_id: str = Field(..., description="The ID of the note to summarize")

class DeleteNoteInput(BaseModel):
    note_id: str = Field(..., description="The ID of the note to delete")

class CreateFolderInput(BaseModel):
    name: str = Field(..., description="The name of the folder")
    description: str = Field("", description="Optional description for the folder")

class CreateNoteInFolderInput(BaseModel):
    title: str = Field(..., description="The title of the note")
    content: str = Field(..., description="The content of the note")
    folder_name: str = Field(None, description="Optional name of the folder to create the note in")
    tags: Optional[List[str]] = Field(None, description="Optional tags for the note")

class RenameFolderInput(BaseModel):
    folder_name: str = Field(..., description="The current name of the folder")
    new_name: str = Field(..., description="The new name for the folder")

class RenameNoteInput(BaseModel):
    note_title: str = Field(..., description="The current title of the note")
    new_title: str = Field(..., description="The new title for the note")

class ResourceManager:
    """Manage API resources dynamically"""
    def __init__(self):
        self.max_concurrent = 3  # Start with conservative limits
        self.batch_size = 5
        self._request_count = 0
        self._error_count = 0
        self._last_adjustment = datetime.now()
        self._adjustment_interval = timedelta(minutes=1)

    async def adjust_limits(self, success: bool):
        """Dynamically adjust resource limits based on success/failure"""
        now = datetime.now()
        if now - self._last_adjustment < self._adjustment_interval:
            return

        if success:
            # Gradually increase limits on successful operations
            self._error_count = max(0, self._error_count - 1)
            if self._error_count == 0:
                self.max_concurrent = min(10, self.max_concurrent + 1)
                self.batch_size = min(20, self.batch_size + 2)
        else:
            # Quickly reduce limits on errors
            self._error_count += 1
            if self._error_count > 2:
                self.max_concurrent = max(1, self.max_concurrent - 1)
                self.batch_size = max(1, self.batch_size - 2)

        self._last_adjustment = now

class SliteAgent:
    """LangChain agent for interacting with Slite with enhanced features"""

    async def clear_memory(self):
        """Clear conversation memory to free up resources"""
        if hasattr(self, 'memory'):
            self.memory.clear()
            logger.info("Cleared conversation memory")

    def __init__(self, api_key: str, gemini_api_key: str = None):
        """Initialize the SliteAgent with API keys and tools"""
        self.api_key = api_key
        self.gemini_api_key = gemini_api_key or os.getenv("GEMINI_API_KEY")
        if not self.gemini_api_key:
            raise ValueError("Gemini API key must be provided")
        
        # Configure Gemini without restrictive limits
        llm = ChatGoogleGenerativeAI(
            model="models/gemini-1.5-pro",
            google_api_key=self.gemini_api_key,
            temperature=0,
            convert_system_message_to_human=False
        )
        
        # Initialize memory without token limits
        self.memory = ConversationSummaryBufferMemory(
            llm=llm,
            memory_key="chat_history",
            return_messages=True
        )

        # Keep periodic cleanup
        self._last_memory_cleanup = datetime.now()
        self._memory_cleanup_interval = timedelta(minutes=5)
        
        # Initialize other attributes
        self.api = SliteAPI(self.api_key)
        self.tools = None
        self.agent_executor = None
        self._session_initialized = False
        self._session_in_use = False
        self._keep_session_alive = True
        self._force_cleanup = False
        self.resource_manager = ResourceManager()

        # Add rate limiting parameters
        self._request_count = 0
        self._last_request_time = datetime.now()
        self._request_window = timedelta(minutes=1)
        self._max_requests_per_minute = 50
        self._retry_delay = 2

        # Update retry configuration
        self._retry_config = retry.Retry(
            initial=1.0,
            maximum=30.0,
            multiplier=1.5,
            predicate=retry.if_exception_type(
                google.api_core.exceptions.ResourceExhausted,
                google.api_core.exceptions.ServiceUnavailable,
            )
        )

    async def _ensure_session(self):
        """Ensure API session is initialized"""
        await self.api.ensure_session()
        self._session_initialized = True

    async def _release_session(self):
        """Release but don't close the session"""
        self._session_in_use = False

    async def initialize_agent(self):
        """Initialize the agent with tools and memory"""
        try:
            if not self.agent_executor:
                # Initialize API session
                await self._ensure_session()
                
                # Initialize tools
                self.tools = SliteTools(self.api)
                
                # Create tools list
                tools = [
                    StructuredTool.from_function(
                        func=self.tools.search_notes,
                        name="SearchNotes",
                        description="Search for notes using a query.",
                        args_schema=SearchNotesInput,
                        coroutine=self.tools.search_notes
                    ),
                    StructuredTool.from_function(
                        func=self.tools.create_note,
                        name="CreateNote",
                        description="Create a new note with title, content, and optional tags.",
                        args_schema=CreateNoteInput,
                        coroutine=self.tools.create_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.update_note,
                        name="UpdateNote",
                        description="Update or append to an existing note.",
                        args_schema=UpdateNoteInput,
                        coroutine=self.tools.update_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.summarize_note,
                        name="SummarizeNote",
                        description="Generate a summary of a note's content.",
                        args_schema=SummarizeNoteInput,
                        coroutine=self.tools.summarize_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.delete_note,
                        name="DeleteNote",
                        description="Delete a note by ID or title.",
                        args_schema=DeleteNoteInput,
                        coroutine=self.tools.delete_note
                    ),
                    StructuredTool.from_function(
                        func=self.tools.create_folder,
                        name="CreateFolder",
                        description="Create a new folder.",
                        args_schema=CreateFolderInput,
                        coroutine=self.tools.create_folder
                    ),
                    StructuredTool.from_function(
                        func=self.tools.create_note_in_folder,
                        name="CreateNoteInFolder",
                        description="Create a new note in a specific folder with title, content, and optional tags.",
                        args_schema=CreateNoteInFolderInput,
                        coroutine=self.tools.create_note_in_folder
                    ),
                    StructuredTool.from_function(
                        func=self.tools.rename_folder,
                        name="RenameFolder",
                        description="Rename a folder.",
                        args_schema=RenameFolderInput,
                        coroutine=self.tools.rename_folder
                    ),
                    StructuredTool.from_function(
                        func=self.tools.rename_note,
                        name="RenameNote",
                        description="Rename a note.",
                        args_schema=RenameNoteInput,
                        coroutine=self.tools.rename_note
                    )
                ]
                
                system_prompt = """You are a helpful assistant that manages notes and folders in Slite.
                
                Available tools:
                1. SearchNotes:
                   - Search for notes using keywords
                   Example: {"query": "meeting notes"}
                
                2. UpdateNote:
                   - Update or append content to an existing note
                   Example: {"note_id": "123", "content": "New content", "append": false}
                
                3. DeleteNote:
                   - Delete a note by ID or title
                   Example: {"note_id": "123"}
                
                4. CreateFolder:
                   - Create a new folder with a given name and optional description
                   Example: {"name": "New Folder", "description": "This is a new folder"}
                
                5. CreateNoteInFolder:
                   - Create a new note in a specific folder with title, content, and optional tags
                   Example: {"title": "New Note", "content": "This is a new note", "folder_name": "Existing Folder", "tags": ["tag1", "tag2"]}
                
                6. RenameFolder:
                   - Rename a folder
                   Example: {"folder_name": "Old Folder", "new_name": "New Folder"}
                
                7. RenameNote:
                   - Rename a note
                   Example: {"note_title": "Old Note", "new_title": "New Note"}
                
                When the user asks to:
                1. Create a document in a folder:
                   - First check if the folder exists using the folder name
                   - If it exists, create the note in that folder
                   - If it doesn't exist, create the folder first, then create the note
                
                2. "Add content" or "update" a note:
                   - Use UpdateNote with append=true on the existing note
                   - If no note ID provided, use the last accessed note
                
                3. "Delete" a note:
                   - Use DeleteNote on the specified note
                   - If no note ID provided, use the last accessed note
                   - Confirm the deletion was successful
                
                4. "Create a new folder":
                   - Use CreateFolder to create a new folder with a given name and optional description
                   
                5. "Create a new note in a folder":
                   - Use CreateNoteInFolder to create a new note in a specific folder
                   - Specify the folder name, not the ID
                   - The folder will be found or created automatically
                
                6. "Rename a folder":
                   - Use RenameFolder to rename a folder
                
                7. "Rename a note":
                   - Use RenameNote to rename a note"""
                
                human_message = HumanMessagePromptTemplate.from_template("{input}\n\nCurrent conversation:\n{agent_scratchpad}")
                chat_prompt = ChatPromptTemplate.from_messages([
                    SystemMessagePromptTemplate.from_template(system_prompt),
                    MessagesPlaceholder(variable_name="chat_history"),
                    human_message
                ])

                self.agent_executor = initialize_agent(
                    tools=tools,
                    llm=ChatGoogleGenerativeAI(
                        model="models/gemini-1.5-pro",  # Updated model name
                        google_api_key=self.gemini_api_key,
                        temperature=0,
                        convert_system_message_to_human=False
                    ),
                    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
                    verbose=True,
                    memory=self.memory,
                    agent_kwargs={
                        "system_message": system_prompt,
                        "input_variables": ["input", "agent_scratchpad", "chat_history"]
                    }
                )
        except Exception as e:
            logger.error(f"Error initializing agent: {str(e)}")
            raise
    
    async def _check_rate_limit(self):
        """Dynamic rate limiting"""
        try:
            current_time = datetime.now()
            
            # Calculate dynamic window based on current load
            window_size = max(1, min(5, self.resource_manager.max_concurrent))
            max_requests = self.resource_manager.batch_size * window_size
            
            if self._request_count >= max_requests:
                delay = 1 + (self._request_count - max_requests) * 0.5
                logger.info(f"Rate limit reached. Adjusting delay: {delay}s")
                await asyncio.sleep(delay)
                self._request_count = 0
                await self.resource_manager.adjust_limits(False)
            else:
                await self.resource_manager.adjust_limits(True)
                
            self._request_count += 1
            
        except Exception as e:
            logger.error(f"Error in rate limiting: {str(e)}")
            await self.resource_manager.adjust_limits(False)

    @tenacity.retry(
        retry=tenacity.retry_if_exception_type(
            (google.api_core.exceptions.ResourceExhausted,
             google.api_core.exceptions.ServiceUnavailable)
        ),
        wait=tenacity.wait_exponential(multiplier=1, min=2, max=30),
        stop=tenacity.stop_after_attempt(3)
    )
    async def process_query(self, query: str) -> str:
        """Process a user query with dynamic resource management"""
        try:
            # Check if memory cleanup is needed
            now = datetime.now()
            if now - self._last_memory_cleanup > self._memory_cleanup_interval:
                await self.clear_memory()
                self._last_memory_cleanup = now

            # Process query with resource management
            await self._check_rate_limit()
            await self._ensure_session()
            
            if not self.agent_executor:
                await self.initialize_agent()
            
            # Check if this is an update operation
            if query.lower().startswith("update") or query.lower().startswith("add content to"):
                # Extract document title
                title = query.split('"')[1] if '"' in query else query.split("update ")[-1].strip()
                
                # Prompt for content
                print("\nEnter/paste your content (Press Ctrl+D on Unix or Ctrl+Z on Windows + Enter on a new line when done):")
                content_lines = []
                while True:
                    try:
                        line = input()
                        content_lines.append(line)
                    except EOFError:
                        break
                
                content = "\n".join(content_lines)
                
                if not content.strip():
                    return "No content provided. Update cancelled."
                
                # Search for the note and update it
                result = await self.tools.update_or_create_note(
                    title=title,
                    content=content,
                    append=False
                )
                
                await self._release_session()  # Release but don't close session
                return f"Document update result:\n{result}"
            else:
                # Handle other types of queries normally
                response = await self.agent_executor.arun(input=query)
                await self._release_session()  # Release but don't close session
                return response
                
        except Exception as e:
            logger.error(f"Error processing query: {str(e)}")
            logger.error(traceback.format_exc())
            return f"Error processing query: {str(e)}"

    async def cleanup(self):
        """Cleanup resources only when explicitly called"""
        if self._force_cleanup:
            await self.api.close(force=True)
            self._session_initialized = False

    async def close(self):
        """Explicitly close the agent and its resources"""
        self._keep_session_alive = False
        self._force_cleanup = True
        await self.cleanup()
        self.api._force_cleanup = True
        await self.api.close(force=True)

    def __del__(self):
        """Ensure cleanup on deletion"""
        if self._session_initialized:
            import asyncio
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self.cleanup())
                else:
                    loop.run_until_complete(self.cleanup())
            except Exception:
                pass

class SliteNoteManager:
    def __init__(self):
        self.api_key = os.getenv('SLITE_API_KEY')
        self.note_manager = NoteManager(self.api_key)

    def process_meeting_notes(self, content: str) -> dict:
        """Process meeting notes and create a note in Slite"""
        try:
            # Extract title from content (assuming markdown format)
            title = "AI Agent Introduction Meeting"
            
            # Create the note
            note = self.note_manager.create_note(title=title, content=content)
            return note
            
        except Exception as e:
            logger.error(f"Error processing meeting notes: {str(e)}")
            raise

    def create_folder_structure(self) -> dict:
        """Create a basic folder structure for organizing notes"""
        try:
            # Create main folder for meetings
            folder = self.note_manager.create_folder(
                name="AI Agent Meetings",
                description="Meeting notes about AI Agent discussions"
            )
            return folder
            
        except Exception as e:
            logger.error(f"Error creating folder structure: {str(e)}")
            raise

    def search_and_update_notes(self, query: str) -> list:
        """Search for notes and update them if needed"""
        try:
            # Search for notes
            results = self.note_manager.search_notes(query)
            return results
            
        except Exception as e:
            logger.error(f"Error searching notes: {str(e)}")
            raise

# Update run_async function to handle cleanup
def run_async(coro):
    """Run an async function in a synchronous context"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    async def wrapped_coro():
        agent = None
        try:
            if isinstance(coro, SliteAgent):
                agent = coro
                await agent._ensure_session()
                return agent
            else:
                return await coro
        finally:
            if agent:
                await agent.cleanup()
    
    return loop.run_until_complete(wrapped_coro())