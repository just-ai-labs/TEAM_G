from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, requests
from pydantic import BaseModel
from typing import Optional
import logging
from agent_demo import AgentDemo

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Slite Integration API",
    description="API for Slite document management and QA system",
    version="1.0.0"
)

# Initialize the AgentDemo instance
agent_demo = AgentDemo()

@app.on_event("startup")
async def startup_event():
    """Initialize the agent on startup"""
    await agent_demo.initialize_agent()

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup resources on shutdown"""
    await agent_demo.cleanup()

# def validate_slite_api_key(api_key: str) -> bool:
#     """Validate the Slite API key by making a request to the Slite API"""
#     url = "https://api.slite.com/v1/users/me"
#     headers = {"Authorization": f"Bearer {api_key}"}
#     response = requests.get(url, headers=headers)
#     logger.debug(f"Slite API validation response: {response.status_code} - {response.text}")
#     return response.status_code == 200

# @app.post("/set-slite-api-key")
# async def set_slite_api_key(slite_api_key: SliteApiKey):
#     if not validate_slite_api_key(slite_api_key.slite_api_key):
#         raise HTTPException(status_code=400, detail="Invalid Slite API key")
#     try:
#         os.environ["SLITE_API_KEY"] = slite_api_key.slite_api_key
#         return {"message": "Slite API key set successfully"}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
    
@app.websocket("/chat")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for interactive chat"""
    await websocket.accept()
    try:
        await agent_demo.initialize_agent()
        await websocket.send_text("Welcome to the Enhanced Slite Agent! I can help you manage your Slite documents and provide QA capabilities.")
        await websocket.send_text("Standard Features:\n1. 'Create a new folder called Meeting Notes'\n2. 'Create a document called January Update in the Meeting Notes folder'\n3. 'Update the January Update document with today's meeting summary'\n4. 'Delete the January Update document'")
        await websocket.send_text("QA Features:\n5. 'list documents' to see available documents\n6. 'select <document name>' to choose a document\n7. Ask questions about the selected document")
        await websocket.send_text("Type 'exit' to quit.")
        
        while True:
            data = await websocket.receive_text()
            if data.lower() == 'exit':
                await websocket.send_text("Exiting interactive mode...")
                break
            if not data:
                continue
            if data.lower() == 'demo':
                await agent_demo.run_demo_sequence()
                await websocket.send_text("Demo sequence completed.")
            else:
                async for response in agent_demo.stream_query(data):
                    await websocket.send_text(response)
    except WebSocketDisconnect:
        logger.info("WebSocket connection closed")
    except Exception as e:
        logger.error(f"Error in WebSocket connection: {str(e)}")
        await websocket.send_text(f"Error: {str(e)}")
    finally:
        await agent_demo.cleanup()