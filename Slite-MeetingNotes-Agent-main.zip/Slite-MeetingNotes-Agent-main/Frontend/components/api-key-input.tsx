"use client"

import React, { useState } from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { KeyRound } from "lucide-react"

interface ApiKeyInputProps {
  onSubmit: (apiKey: string) => void
}

export function ApiKeyInput({ onSubmit }: ApiKeyInputProps) {
  const [apiKey, setApiKey] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (apiKey.trim()) {
      onSubmit(apiKey.trim())
    }
  }

  return (
    <div className="flex flex-col items-center justify-center h-full">
      <div className="w-full max-w-md space-y-6 p-6 bg-white rounded-lg shadow-sm border">
        <div className="flex flex-col items-center text-center space-y-2">
          <KeyRound className="h-12 w-12 text-primary" />
          <h3 className="text-xl font-semibold">Slite API Key Required</h3>
          <p className="text-sm text-gray-500">
            Please enter your Slite API key to continue. Your key will be stored securely in your browser.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="apiKey">API Key</Label>
            <Input
              id="apiKey"
              type="password"
              placeholder="Enter your API key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={!apiKey.trim()}>
            Continue
          </Button>
        </form>
      </div>
    </div>
  )
}

