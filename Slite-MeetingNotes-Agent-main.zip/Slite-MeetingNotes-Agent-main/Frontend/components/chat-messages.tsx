"use client"

import { useRef, useEffect } from "react"
import { User, Bot, AlertCircle, RefreshCw } from "lucide-react"
import ReactMarkdown from "react-markdown"

interface Message {
  id: string
  role: "user" | "assistant" | "system" | "data"
  content: string
}

interface ChatMessagesProps {
  messages: Message[]
  isLoading: boolean
  error: Error | null
  onRetry: () => void
}

export function ChatMessages({ messages, isLoading, error, onRetry }: ChatMessagesProps) {
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current
      scrollContainer.scrollTop = scrollContainer.scrollHeight
    }
  }, [messages])

  return (
    <div ref={scrollAreaRef} className="flex-1 overflow-auto p-4">
      {messages.map((message, index) => (
        <div
          key={index}
          className={`flex items-start space-x-4 p-4 my-2 rounded-md max-w-[75%] ${
            message.role === "user" ? "bg-gray-200 ml-auto" : "bg-gray-300 mr-auto"
          }`}
        >
          {message.role === "user" ? (
            <>
              <div className="flex-1 text-right">
                <ReactMarkdown>{message.content}</ReactMarkdown>
              </div>
              <User className="h-6 w-6 text-black" />
            </>
          ) : (
            <>
              <Bot className="h-6 w-6 text-blue-500" />
              <div className="flex-1">
                <ReactMarkdown>{message.content}</ReactMarkdown>
              </div>
            </>
          )}
        </div>
      ))}
      {isLoading && (
        <div className="flex items-center space-x-2 p-4 my-2 rounded-md bg-gray-300 max-w-[75%] mr-auto">
          <Bot className="h-6 w-6 text-blue-500" />
          <div className="flex-1">Loading...</div>
        </div>
      )}
      {error && (
        <div className="flex items-center space-x-2 p-4 my-2 rounded-md bg-red-200 max-w-[75%] mr-auto">
          <AlertCircle className="h-6 w-6 text-red-500" />
          <div className="flex-1">{error.message}</div>
          <button onClick={onRetry} className="text-blue-500">
            <RefreshCw className="h-6 w-6" />
          </button>
        </div>
      )}
    </div>
  )
}