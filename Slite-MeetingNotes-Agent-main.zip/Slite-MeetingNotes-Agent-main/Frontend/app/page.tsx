"use client"

import { useState, useEffect } from "react"
import { ChatInput } from "@/components/chat-input"
import { ChatMessages } from "@/components/chat-messages"
import { ApiKeyInput } from "@/components/api-key-input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface Message {
  id: string
  role: "user" | "assistant" | "system" | "data"
  content: string
}

export default function ChatPage() {
  const [apiKey, setApiKey] = useState<string>("")
  const [apiKeySubmitted, setApiKeySubmitted] = useState<boolean>(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState<string>("")
  const [error, setError] = useState<string>("")
  const [ws, setWs] = useState<WebSocket | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)

  useEffect(() => {
    if (apiKeySubmitted) {
      const websocket = new WebSocket("ws://127.0.0.1:8000/chat")
      websocket.onopen = () => {
        websocket.send(JSON.stringify({ apiKey }))
      }
      websocket.onmessage = (event) => {
        const message: Message = { id: Date.now().toString(), role: "assistant", content: event.data }
        setMessages((prevMessages) => [...prevMessages, message])
        setIsLoading(false)
      }
      websocket.onerror = () => {
        setError("WebSocket error")
        setIsLoading(false)
      }
      websocket.onclose = () => {
        setWs(null)
      }
      setWs(websocket)
    }
  }, [apiKeySubmitted])

  const handleApiKeySubmit = (key: string) => {
    setApiKey(key)
    setApiKeySubmitted(true)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (ws && input.trim()) {
      const message: Message = { id: Date.now().toString(), role: "user", content: input.trim() }
      setMessages((prevMessages) => [...prevMessages, message])
      ws.send(input.trim())
      setInput("")
      setIsLoading(true)
    }
  }

  const handleRetry = () => {
    setError("")
    setApiKeySubmitted(false)
    setMessages([])
    setInput("")
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50 p-4">
      <Card className="w-full max-w-3xl h-[80vh] flex flex-col">
        <CardHeader>
          <CardTitle>Slite AI Agent</CardTitle>
          <CardDescription>Ask me anything About Slite Meeting Notes and I'll try to help you</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col overflow-hidden">
          {!apiKeySubmitted ? (
            <ApiKeyInput onSubmit={handleApiKeySubmit} />
          ) : (
            <>
              <ChatMessages messages={messages} isLoading={isLoading} error={error ? new Error(error) : null} onRetry={handleRetry} />
              <ChatInput input={input} handleInputChange={handleInputChange} handleSubmit={handleSubmit} isLoading={isLoading} />
            </>
          )}
        </CardContent>
      </Card>
      {error && <div className="text-red-500">{error}</div>}
    </div>
  )
}