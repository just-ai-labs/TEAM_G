import { Configuration, OpenAIApi } from 'openai'
import dotenv from 'dotenv'

// Load environment variables from .env file
dotenv.config()

export async function POST(req: Request) {
  try {
    // Get the request body
    const body = await req.json()
    const { apiKey, messages } = body

    if (!apiKey) {
      return new Response(JSON.stringify({ error: "API key is required" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      })
    }

    // Initialize the OpenAI client with the provided API key
    const configuration = new Configuration({
      apiKey: apiKey,
    })
    const openai = new OpenAIApi(configuration)

    // Create the completion
    const response = await openai.createChatCompletion({
      model: "gpt-4", // Use a valid model ID
      messages: messages,
    })

    // Stream the response
    const stream = new ReadableStream({
      start(controller) {
        const encoder = new TextEncoder()
        response.data.choices.forEach(choice => {
          if (choice.message && choice.message.content) {
            controller.enqueue(encoder.encode(choice.message.content))
          }
        })
        controller.close()
      }
    })

    return new Response(stream, {
      headers: { "Content-Type": "text/plain" },
    })
  } catch (error) {
    console.error("Error in chat API:", error)
    return new Response(JSON.stringify({ error: "Failed to process your request" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

