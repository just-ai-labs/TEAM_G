# Slite Meeting Notes Agent Documentation

## Overview
The Slite Meeting Notes Agent is an AI-powered integration solution for automating Slite meeting notes management and documentation workflows. This project combines the power of LangChain and OpenAI to provide intelligent note processing, organization, and search capabilities.

## Features
- Automated Note Creation: Automatically create and organize meeting notes in Slite.
- Document Management: Manage documents and folders within Slite.
- Search and Query: Search and query documents using natural language.
- Real-time Collaboration: Collaborate in real-time with WebSocket support.

## Technologies Used
- Backend: FastAPI, Python, LangChain, OpenAI, aiohttp, requests
- Frontend: React, Next.js, Tailwind CSS
- Containerization: Docker, Docker Compose

## Prerequisites
- Python 3.8 or higher
- Node.js and npm
- Docker and Docker Compose

## Installation

### Backend
Clone the repository:
```bash
git clone https://github.com/yourusername/Slite-MeetingNotes-Agent.git
cd Slite-MeetingNotes-Agent/Backend
```

Create a virtual environment:
```bash
python -m venv venv
```

Activate the virtual environment:

On Windows:
```bash
venv\Scripts\activate
```

On macOS/Linux:
```bash
source venv/bin/activate
```

Install the required packages:
```bash
pip install -r requirements.txt
```

Create a `.env` file in the Backend directory and add the necessary environment variables:
```env
SLITE_API_KEY="your_slite_api_key"
OPENAI_API_KEY="your_openai_api_key"
```

### Frontend
Navigate to the frontend directory:
```bash
cd ../Frontend
```

Install the required packages:
```bash
npm install
```

### Docker Setup
Create a `docker-compose.yaml` file in the root directory:
```yaml
services:
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    depends_on:
      - backend
    environment:
      - NODE_ENV=production

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    environment:
      - ENV=production
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - SLITE_API_KEY=${SLITE_API_KEY}
      - LOG_LEVEL=${LOG_LEVEL:-INFO}
      - CACHE_TTL=${CACHE_TTL:-300}
    volumes:
      - ./backend/.env:/app/.env
```

Build and run the Docker containers:
```bash
docker-compose up --build
```

## Backend API Creation

### FastAPI Setup
Create a FastAPI application in `server.py`:
```python
// ...existing code...
```

### Backend API Endpoints

#### POST /set-slite-api-key:
- Validates and sets the Slite API key.
- Request body: `{ "slite_api_key": "your_slite_api_key" }`
- Response: `{ "message": "Slite API key set successfully" }`


#### WebSocket /chat:
- Provides real-time chat capabilities for interacting with the agent.

## Frontend Creation
Create a Next.js application in the Frontend directory:
```bash
// ...existing code...
```

### Create the ApiKeyInput component:
- Create a form to input the Slite API key.
- Handle form submission and send the API key to the backend.
- Display error messages if the API key is invalid.

### Create the main page in `Frontend/pages/index.tsx`:
- Create a state to manage the API key and submission status.
- Create a WebSocket connection to the backend for real-time chat.
- Handle user input and send messages to the WebSocket.
- Display chat messages and handle errors.

## Running the Application

### Backend
Start the FastAPI server:
```bash
uvicorn server:app --reload
```

Access the backend application: Open your web browser and go to `http://127.0.0.1:8000`.

### Frontend
Start the frontend development server:
```bash
npm run dev
```

Access the frontend application: Open your web browser and go to `http://localhost:3000`.

## Testing

### Backend
Run the tests:
```bash
pytest
```

### Frontend
Run the tests:
```bash
npm run test
```

## Contributing
If you would like to contribute to this project, please fork the repository and submit a pull request.

## License
This project is licensed under the MIT License.

## Support
For support, please open an issue in the GitHub repository.

## Roadmap
- Add more features for document management.
- Improve the AI capabilities for better note processing.
- Add user authentication and authorization.
- Implement real-time Slite API key validation and authentication.
- Enhance stability and performance of the application.

This documentation provides a comprehensive guide to setting up, running, and contributing to the Slite Meeting Notes Agent application.
